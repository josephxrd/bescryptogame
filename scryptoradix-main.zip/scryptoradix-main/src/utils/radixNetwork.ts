import config from '../config/index.js'

export function getRadixURL() {
  return config.radix.url;
}

export function getRadixNetwork() {
  return config.radix.network;
}

