import { Hono } from 'hono';

export const homeRoute = new Hono();

homeRoute.get('/', (c) => {
  return c.json({ message: 'Welcome to Scryptron Arena' });
});