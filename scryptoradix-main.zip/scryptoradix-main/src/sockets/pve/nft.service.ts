// modules/pve/nft.service.ts
import { supabase } from "../../lib/supabase.js";

/**
 * Ambil NFT player berdasarkan userId dan daftar ID NFT yang dipilih.
 */
export async function getPlayerNFTs(userId: string, nftIds: number[]) {
  const { data, error } = await supabase
    .from("nfts")
    .select("*")
    .eq("owner_account", userId)
    .in("id", nftIds)
    .order("role", { ascending: true });

  if (error) throw error;
  return data || [];
}

/**
 * Ambil NFT bot berdasarkan level.
 */
export async function getBotNFTs(levelId: number) {
  const { data, error } = await supabase
    .from("pve_level_nfts")
    .select("id, name, role, level, hp, atk, def, spd, image_url, description")
    .eq("level_id", levelId)
    .order("role", { ascending: true });

  if (error) throw error;
  return data || [];
}
