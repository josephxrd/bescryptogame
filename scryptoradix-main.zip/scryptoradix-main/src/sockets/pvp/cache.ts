// sockets/pvp/cache.ts

/**
 * Tipe data untuk battle PVP
 */
export interface PVPBattle {
  battleId: string;
  battleMode: "alpha" | "team"; // alpha = 1v1, team = 3v3
  player1Id: string;
  player2Id: string;
  player1Team: any[];
  player2Team: any[];
  firstTurnPlayerId: string; // Siapa yang main duluan
  status: "waiting" | "in_progress" | "finished";
  winner?: string; // userId yang menang
  createdAt: number;
}

/**
 * Tipe data untuk room menunggu opponent
 */
export interface WaitingRoom {
  userId: string;
  username: string; // Username untuk display
  battleMode: "alpha" | "team";
  team: any[];
  joinedAt: number;
  lastHeartbeat: number; // Untuk track last activity
  matchMode: "create" | "join"; // Mode: create room atau join room
  isCreator: boolean; // TRUE jika user adalah room creator, FALSE jika user adalah joiner
  matchedOpponentId?: string; // ID opponent jika sudah matched
  opponentTeam?: any[]; // Team opponent jika sudah matched
}

/**
 * Cache untuk battle yang sedang berlangsung
 */
export const activeBattlesCache = new Map<string, PVPBattle>();

/**
 * Cache untuk user yang menunggu opponent (matchmaking)
 */
export const waitingRoomsCache = new Map<string, WaitingRoom>();

/**
 * Map untuk socket ID ke user ID (untuk disconnection handling)
 */
export const socketToUserMap = new Map<string, string>();


