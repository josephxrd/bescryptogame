// sockets/pvp/reward.service.ts
import { supabase } from "../../lib/supabase.js";

/**
 * Terapkan reward untuk kedua player setelah PVP battle selesai
 * Winner mendapat lebih banyak reward dibanding loser
 */
export async function applyPVPBattleReward(
  winnerId: string,
  loserId: string,
  battleMode: "alpha" | "team",
  winnerTeam: { id: string; position: string; role: string }[],
  loserTeam: { id: string; position: string; role: string }[]
) {
  try {
    // =============================================
    // WINNER REWARDS
    // =============================================
    await applyPlayerReward(winnerId, "winner", battleMode, winnerTeam);

    // =============================================
    // LOSER REWARDS
    // =============================================
    await applyPlayerReward(loserId, "loser", battleMode, loserTeam);
  } catch (err: any) {
    console.error("Error applying PVP rewards:", err.message);
  }
}

/**
 * Terapkan reward untuk kedua player ketika PVP battle DRAW
 * Kedua player mendapat reward yang sama (draw reward)
 */
export async function applyPVPBattleDrawReward(
  player1Id: string,
  player2Id: string,
  battleMode: "alpha" | "team",
  player1Team: { id: string; position: string; role: string }[],
  player2Team: { id: string; position: string; role: string }[]
) {
  try {
    // =============================================
    // PLAYER 1 DRAW REWARDS
    // =============================================
    await applyPlayerReward(player1Id, "draw", battleMode, player1Team);

    // =============================================
    // PLAYER 2 DRAW REWARDS
    // =============================================
    await applyPlayerReward(player2Id, "draw", battleMode, player2Team);
  } catch (err: any) {
    console.error("Error applying PVP draw rewards:", err.message);
  }
}

/**
 * Terapkan reward untuk satu player
 * status: "winner" | "loser" | "draw"
 */
async function applyPlayerReward(
  userId: string,
  status: "winner" | "loser" | "draw",
  battleMode: "alpha" | "team",
  team: { id: string; position: string; role: string }[]
) {
  try {
    // === AMBIL USER DATA ===
    const { data: userData } = await supabase
      .from("users")
      .select("coins, exp, total_exp, max_exp, level, pvp_wins, pvp_losses, pvp_draws, arena_points")
      .eq("account_address", userId)
      .single();

    if (!userData) return;

    let { coins, exp, total_exp, max_exp, level, pvp_wins, pvp_losses, pvp_draws, arena_points } =
      userData;

    // === TENTUKAN REWARD BERDASARKAN STATUS ===
    let rewardGold = 0;
    let profileXp = 0;
    let nftXpGain = 0;
    let arenaPointsChange = 0;

    if (status === "winner") {
      rewardGold = 100;
      profileXp = 50;
      nftXpGain = 50;
      arenaPointsChange = 20;
      pvp_wins = (pvp_wins || 0) + 1;
    } else if (status === "loser") {
      rewardGold = 50;
      profileXp = 0;
      nftXpGain = 0;
      arenaPointsChange = -15;
      pvp_losses = (pvp_losses || 0) + 1;
    } else if (status === "draw") {
      // Draw reward: tengah-tengah antara winner dan loser
      rewardGold = 25;
      profileXp = 0;
      nftXpGain = 25;
      arenaPointsChange = 5;
      pvp_draws = (pvp_draws || 0) + 1;
    }

    // =============================================
    // UPDATE NFT XP & LEVEL
    // =============================================
    const selectedNFTIds = team.map((t) => Number(t.id));
    const { data: nfts } = await supabase
      .from("nfts")
      .select("id, exp, exp_max, level, attribute_points, role")
      .in("id", selectedNFTIds);

    if (nfts && nfts.length > 0) {
      for (const nft of nfts) {
        let newExp = nft.exp + nftXpGain;
        let newLevel = nft.level;
        let newExpMax = nft.exp_max || 100;
        let attributePoints = nft.attribute_points || 0;

        // Level up jika exp >= exp_max
        while (newExp >= newExpMax) {
          newExp -= newExpMax;
          newLevel++;
          newExpMax = Math.round(newExpMax * 1.25);
          attributePoints += 5;
        }

        await supabase
          .from("nfts")
          .update({
            exp: newExp,
            exp_max: newExpMax,
            level: newLevel,
            attribute_points: attributePoints,
            updated_at: new Date().toISOString(),
          })
          .eq("id", nft.id);
      }
    }

    // =============================================
    // SET ROLE NFT (jika belum punya)
    // =============================================
    const positionToRole: Record<string, string> = {
      front: "Frontline",
      mid: "Attacker",
      back: "Backline",
    };

    if (nfts && nfts.length > 0) {
      for (const nft of nfts) {
        // Skip jika sudah memiliki role
        if (nft.role && nft.role.trim() !== "") continue;

        const meta = team.find((t) => String(t.id) === String(nft.id));
        if (!meta) continue;

        const mappedRole =
          positionToRole[meta.position as keyof typeof positionToRole] || "";

        if (mappedRole) {
          await supabase
            .from("nfts")
            .update({
              role: mappedRole,
              updated_at: new Date().toISOString(),
            })
            .eq("id", nft.id);
        }
      }
    }

    // =============================================
    // UPDATE USER PROFILE
    // =============================================
    coins += rewardGold;
    exp += profileXp;
    total_exp += profileXp;
    arena_points = Math.max(0, arena_points + arenaPointsChange);

    // Level up user jika exp >= max_exp
    while (exp >= max_exp) {
      exp -= max_exp;
      level++;
      max_exp = Math.round(max_exp * 1.2);
    }

    await supabase
      .from("users")
      .update({
        coins,
        exp,
        total_exp,
        max_exp,
        level,
        pvp_wins,
        pvp_losses,
        pvp_draws,
        arena_points,
        updated_at: new Date().toISOString(),
      })
      .eq("account_address", userId);
  } catch (err: any) {
    console.error(`Error applying reward for ${userId}:`, err.message);
  }
}
