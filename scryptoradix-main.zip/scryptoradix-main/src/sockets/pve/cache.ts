// modules/pve/cache.ts
export const activeBattlesCache = new Map<string, any>();
