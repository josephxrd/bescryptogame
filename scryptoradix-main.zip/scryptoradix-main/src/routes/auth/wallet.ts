import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";
import type { RadixWalletResponse, User } from "../../types/index.js";

export const walletRoute = new Hono();

walletRoute.post("/connect", async (c) => {
  try {
    const body: RadixWalletResponse = await c.req.json();
    const { data } = body;

    const identityAddress = data.identityAddress;
    const personaLabel = data.persona?.label ?? "Unknown";
    const account = data.accounts?.[0];
    const accountAddress = account?.address ?? null;
    const accountLabel = account?.label ?? "Main Account";

    if (!accountAddress) {
      return c.json({ error: "Missing account address" }, 400);
    }

    // 🔍 Cek user berdasarkan account_address (bukan hanya identity_address)
    const { data: existingUser, error: findError } = await supabase
      .from("users")
      .select("*")
      .eq("account_address", accountAddress)
      .maybeSingle();

    if (findError) {
      console.error("Find user error:", findError);
      return c.json({ error: "Database query failed" }, 500);
    }

    let user: User;

    if (!existingUser) {
      // 🧩 Buat user baru jika belum ada
      const { data: newUser, error: insertError } = await supabase
        .from("users")
        .insert([
          {
            identity_address: identityAddress,
            persona_label: personaLabel,
            account_address: accountAddress,
            account_label: accountLabel,
            arena_points: 1000,
          },
        ])
        .select()
        .single();

      if (insertError || !newUser) {
        console.error("Insert user error:", insertError);
        return c.json({ error: "Failed to create new user" }, 500);
      }

      user = newUser as User;
    } else {
      // 🔁 Update user yang sudah ada
      const { data: updatedUser, error: updateError } = await supabase
        .from("users")
        .update({
          identity_address: identityAddress,
          persona_label: personaLabel,
          account_label: accountLabel,
          updated_at: new Date().toISOString(),
        })
        .eq("account_address", accountAddress)
        .select()
        .single();

      if (updateError || !updatedUser) {
        console.error("Update user error:", updateError);
        return c.json({ error: "Failed to update user" }, 500);
      }

      user = updatedUser as User;
    }

    return c.json({
      message: "Wallet connected successfully",
      user,
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

walletRoute.post("/disconnect", async (c) => {
  try {
    // Kalau nanti ada auth/session logic, tambahkan di sini
    return c.json({ message: "Wallet disconnected" });
  } catch (error) {
    console.error("Disconnect error:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});
