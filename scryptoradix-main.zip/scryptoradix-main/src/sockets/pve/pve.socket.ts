// modules/pve/pve.socket.ts
import { Server } from "socket.io";
import { registerBattleHandlers } from "./battle.handlers.js";

export const setupPveSocket = (io: Server) => {
  const pve = io.of("/pve");

  pve.on("connection", (socket) => {
    registerBattleHandlers(socket, io);

    socket.on("disconnect", () => {
    });
  });
};
