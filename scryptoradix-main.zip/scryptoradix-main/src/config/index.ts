import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Get the directory of this file (src/config)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Navigate to project root (src/config -> src -> . )
const rootDir = path.resolve(__dirname, "../..");

// Determine which .env file to load based on NODE_ENV
const nodeEnvValue = process.env.NODE_ENV || "development";
const envFile =
  nodeEnvValue === "production" ? ".env.production" : ".env";

// Load the appropriate .env file
const envPath = path.resolve(rootDir, envFile);
console.log(`📄 Loading env from: ${envPath}`);

dotenv.config({
  path: envPath,
});

export type Environment = "development" | "production";

const nodeEnv = (process.env.NODE_ENV || "development") as Environment;
const isDevelopment = nodeEnv === "development";
const isProduction = nodeEnv === "production";

/**
 * Environment Configuration
 * Dynamically loads configuration based on NODE_ENV
 */
export const config = {
  // Server
  nodeEnv,
  isDevelopment,
  isProduction,
  port: process.env.PORT ? parseInt(process.env.PORT) : 3000,

  // Supabase Configuration
  supabase: {
    url: process.env.SUPABASE_URL || "",
    anonKey: process.env.SUPABASE_ANON_KEY || "",
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  },

  // Radix Network Configuration
  radix: {
    network: (process.env.RADIX_NETWORK || "stokenet") as "mainnet" | "stokenet",
    mainnetUrl: process.env.RADIX_MAINNET_URL || "https://mainnet.radixdlt.com",
    stokenetUrl: process.env.RADIX_STOKENET_URL || "https://stokenet.radixdlt.com",
    get url() {
      return this.network === "mainnet" ? this.mainnetUrl : this.stokenetUrl;
    },
  },

  // Redis Configuration (if needed)
  redis: {
    host: process.env.REDIS_HOST || "localhost",
    port: process.env.REDIS_PORT ? parseInt(process.env.REDIS_PORT) : 6379,
  },
};

// Validate required configuration
const requiredVars = [
  "SUPABASE_URL",
  "SUPABASE_SERVICE_ROLE_KEY",
  "RADIX_NETWORK",
];

const missingVars = requiredVars.filter((v) => !process.env[v]);

if (missingVars.length > 0) {
  console.error(
    "❌ Missing required environment variables:",
    missingVars.join(", ")
  );
  if (isProduction) {
    throw new Error("Missing required environment variables");
  }
}

// Log configuration on startup
console.log("🔧 Environment Configuration:");
console.log(`   NODE_ENV: ${nodeEnv}`);
console.log(`   Config File: ${envFile}`);
console.log(`   Radix Network: ${config.radix.network}`);
console.log(`   Radix URL: ${config.radix.url}`);

export default config;
