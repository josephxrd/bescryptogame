import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";

const route = new Hono();

/**
 * GET /pvp/alpha/battle/:battleId/stats/defeat
 * Ambil statistik kekalahan untuk alpha battle
 */
route.get("/battle/:battleId/stats/defeat", async (c) => {
  try {
    const battleId = c.req.param("battleId");

    if (!battleId) {
      return c.json({ error: "Missing battleId parameter" }, 400);
    }

    // Ambil data battle
    const { data: battle, error } = await supabase
      .from("pvp_battles")
      .select("*")
      .eq("battle_id", battleId)
      .single();

    if (error || !battle) {
      return c.json({ error: "Battle not found" }, 404);
    }

    // Hitung duration dari logs
    const { data: logs } = await supabase
      .from("pvp_battle_logs")
      .select("timestamp")
      .eq("battle_id", battleId)
      .order("timestamp", { ascending: false })
      .limit(1);

    const duration =
      logs && logs.length > 0 ? logs[0].timestamp - battle.created_at : 0;

    // Jika battle belum selesai
    if (battle.winner_id === null && (!logs || logs.length === 0)) {
      return c.json({ error: "Battle not finished" }, 400);
    }

    // Tentukan status: draw atau defeat
    const status = battle.winner_id === null ? "draw" : "defeat";

    return c.json({
      battleId,
      winnerId: battle.winner_id,
      loserId: battle.loser_id,
      status: status,
      durationSeconds: Math.floor(duration / 1000),
      stats: {
        finalProgress: battle.final_player2_progress,
        opponentProgress: battle.final_player1_progress,
        battleMode: "alpha",
      },
      rewards: {
        gold: 50,
        experience: 0,
        nftExperience: 0,
      },
    });
  } catch (error: any) {
    console.error("Error fetching defeat stats:", error.message);
    return c.json({ error: "Internal server error" }, 500);
  }
});

export default route;
