import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/team/battle/:battleId/stats/victory
 * Ambil statistik kemenangan untuk team battle
 */
route.get('/battle/:battleId/stats/victory', async (c) => {
  try {
    const battleId = c.req.param('battleId');

    if (!battleId) {
      return c.json({ error: 'Missing battleId parameter' }, 400);
    }

    // Ambil data battle
    const { data: battle, error } = await supabase
      .from('pvp_battles')
      .select('*')
      .eq('battle_id', battleId)
      .single();

    if (error || !battle) {
      return c.json({ error: 'Battle not found' }, 404);
    }

    if (battle.winner_id === null) {
      return c.json({ error: 'Battle not finished or was a draw' }, 400);
    }

    // Hitung duration dari logs
    const { data: logs } = await supabase
      .from('pvp_battle_logs')
      .select('timestamp')
      .eq('battle_id', battleId)
      .order('timestamp', { ascending: false })
      .limit(1);

    const duration = logs && logs.length > 0 
      ? logs[0].timestamp - battle.created_at 
      : 0;

    return c.json({
      battleId,
      winnerId: battle.winner_id,
      loserId: battle.loser_id,
      status: 'victory',
      durationSeconds: Math.floor(duration / 1000),
      stats: {
        finalProgress: battle.final_player1_progress,
        opponentProgress: battle.final_player2_progress,
        battleMode: 'team',
        teamSize: 3,
      },
      rewards: {
        gold: 100,
        experience: 50,
        nftExperiencePerMember: 50,
      },
    });
  } catch (error: any) {
    console.error('Error fetching victory stats:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;