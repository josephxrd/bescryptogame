import { Hono } from 'hono';

const route = new Hono();

route.get('/challenge/:challengeId', async (c) => {
  try {
    const challengeId = c.req.param('challengeId');
    // Add challenge info logic here
    return c.json({ message: `Challenge ${challengeId} info` });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;