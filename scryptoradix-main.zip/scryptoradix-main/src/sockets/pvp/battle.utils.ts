// sockets/pvp/battle.utils.ts

/**
 * Hitung total power dari satu tim
 * Formula: HP * 0.5 + ATK * 1.2 + SPD * 1.1 + DEF * 0.8
 */
export function calculateTeamPower(team: any[]): number {
  return team.reduce(
    (sum, nft) => sum + nft.hp * 0.5 + nft.atk * 1.2 + nft.spd * 1.1 + nft.def * 0.8,
    0
  );
}

/**
 * Tentukan siapa yang main duluan berdasarkan random atau power comparison
 * Opsional: Bisa juga based on first NFT speed/attribute
 */
export function determineFirstTurn(
  player1Id: string,
  player2Id: string
): string {
  // Random: 50-50 chance
  return Math.random() > 0.5 ? player1Id : player2Id;

  // Alternatif: Based on team power (lebih kuat main duluan)
  // return player1Power >= player2Power ? player1Id : player2Id;
}

/**
 * Validasi bahwa team memiliki role yang sesuai
 * Untuk alpha (1v1): 1 NFT
 * Untuk team (3v3): 3 NFT dengan role berbeda (Frontline, Attacker, Backline)
 */
export function validateTeamComposition(
  team: any[],
  battleMode: "alpha" | "team"
): { valid: boolean; error?: string } {
  if (battleMode === "alpha") {
    // if (team.length !== 1) {
    //   return { valid: false, error: "Alpha mode requires exactly 1 NFT" };
    // }
    return { valid: true };
  }

  if (battleMode === "team") {
    // if (team.length !== 3) {
    //   return { valid: false, error: "Team mode requires exactly 3 NFTs" };
    // }

    // Cek role diversity
    const roles = team.map((t) => t.position || t.role).filter(Boolean);
    const uniqueRoles = new Set(roles);

    if (uniqueRoles.size < 2) {
      return {
        valid: false,
        error: "Team should have diverse roles (Frontline, Attacker, Backline)",
      };
    }

    return { valid: true };
  }

  return { valid: false, error: "Invalid battle mode" };
}

/**
 * Map position ke role
 */
const positionToRoleMap: Record<string, string> = {
  front: "Frontline",
  mid: "Attacker",
  back: "Backline",
  frontline: "Frontline",
  attacker: "Attacker",
  backline: "Backline",
};

/**
 * Get role dari position atau existing role
 */
export function getRoleFromPosition(
  nft: any,
  position: string
): string {
  if (nft.role && nft.role.trim() !== "") {
    return nft.role;
  }

  return positionToRoleMap[position.toLowerCase()] || "Frontline";
}
