// sockets/pvp/battle.handlers.ts
import {
  activeBattlesCache,
  waitingRoomsCache,
  socketToUserMap,
} from "./cache.js";
import { getPlayerNFTs } from "./nft.service.js";
import {
  determineFirstTurn,
  validateTeamComposition,
  getRoleFromPosition,
  calculateTeamPower,
} from "./battle.utils.js";
import { simulateRealtimePVPBattle } from "./battle.simulation.js";
import { applyPVPBattleReward } from "./reward.service.js";
import { supabase } from "../../lib/supabase.js";

export function registerBattleHandlers(socket: any, io: any) {
  /**
   * =========================================
   * CREATE MATCH (DARI FRONTEND)
   * Saat user klik "Create Match", backend akan setup room
   * =========================================
   */
  socket.on(
    "CREATE_MATCH",
    ({
      userId,
      battleMode,
    }: {
      userId: string;
      battleMode: "alpha" | "team";
    }) => {
      try {
        // PENTING: Check if user already has an existing room
        const existingRoom = waitingRoomsCache.get(userId);
        if (existingRoom) {
          console.warn(
            "[CREATE_MATCH] User already has a room:",
            { userId, existingMode: existingRoom.matchMode }
          );
          socket.emit("ROOM_UPDATE", {
            error: `You are already in ${existingRoom.matchMode} mode. Cannot switch modes. Please cancel current room first.`,
            resetState: false,
            currentMode: existingRoom.matchMode,
          });
          return;
        }

        // Map socket ke user ID
        socketToUserMap.set(socket.id, userId);

        // Emit success response ke frontend
        socket.emit("MATCH_CREATED", {
          userId,
          battleMode,
          message: "Match room created. Ready to select team.",
        });
      } catch (err: any) {
        console.error("Error in CREATE_MATCH:", err.message);
        socket.emit("ERROR", { message: "Failed to create match" });
      }
    }
  );

  /**
   * =========================================
   * GET AVAILABLE ROOMS / OPPONENTS
   * Request list dari waiting rooms yang available
   * =========================================
   */
  socket.on(
    "GET_AVAILABLE_ROOMS",
    ({
      battleMode,
      userId,
    }: {
      battleMode: "alpha" | "team";
      userId: string;
    }) => {
      try {
        const now = Date.now();

        // Get all waiting rooms for this battle mode
        const availableRooms = Array.from(waitingRoomsCache.values())
          .filter(
            (room) => room.battleMode === battleMode && room.userId !== userId // Exclude own room
          )
          .map((room) => ({
            userId: room.userId,
            username: room.username || room.userId,
            battleMode: room.battleMode,
            joinedAt: room.joinedAt,
            waitingTime: now - room.joinedAt,
          }));

        socket.emit("AVAILABLE_ROOMS", {
          battleMode,
          rooms: availableRooms,
          count: availableRooms.length,
        });
      } catch (err: any) {
        console.error("Error in GET_AVAILABLE_ROOMS:", err.message);
        socket.emit("ERROR", { message: "Failed to fetch available rooms" });
      }
    }
  );

  /**
   * =========================================
   * HEARTBEAT - Keep room alive
   * Frontend sends heartbeat every 30 seconds to indicate user is active
   * =========================================
   */
  socket.on("ROOM_HEARTBEAT", ({ userId }: { userId: string }) => {
    try {
      const room = waitingRoomsCache.get(userId);
      if (room) {
        // Update last heartbeat time
        room.lastHeartbeat = Date.now();
      }
    } catch (err: any) {
      console.error("Error in ROOM_HEARTBEAT:", err.message);
    }
  });
  socket.on(
    "SELECT_TEAM_PVP",
    async ({
      userId,
      battleMode,
      team,
      matchMode,
    }: {
      userId: string;
      battleMode: "alpha" | "team";
      team: { id: number; position: string }[];
      matchMode: "create" | "join";
    }) => {
      try {
        // PENTING: Check if user already has a room in waiting
        const existingRoom = waitingRoomsCache.get(userId);
        if (existingRoom) {
          console.warn(
            "[SELECT_TEAM_PVP] User already has an active room. isCreator:",
            existingRoom.isCreator,
            "matchMode attempt:",
            matchMode
          );
          // Prevent changing isCreator once already set
          if (existingRoom.isCreator !== (matchMode === "create")) {
            socket.emit("ROOM_UPDATE", {
              error: `You are already in ${existingRoom.matchMode} mode. Cannot switch modes. Please cancel current room first.`,
              resetState: false,
              currentMode: existingRoom.matchMode,
            });
            return;
          }
        }

        // Validasi team composition
        const validation = validateTeamComposition(team, battleMode);
        if (!validation.valid) {
          console.warn("[SELECT_TEAM_PVP] Validation failed:", validation.error);
          socket.emit("ROOM_UPDATE", { 
            error: validation.error,
            resetState: true 
          });
          return;
        }

        // Fetch player NFTs
        const selectedNFTIds = team.map((t) => t.id);
        const playerNFTs = await getPlayerNFTs(userId, selectedNFTIds);

        if (!playerNFTs || playerNFTs.length === 0) {
          console.error("[SELECT_TEAM_PVP] No valid NFTs found for:", {
            userId,
            selectedNFTIds,
          });
          socket.emit("ROOM_UPDATE", { 
            error: "No valid NFTs found",
            resetState: true 
          });
          return;
        }

        // Enrich team dengan role dari position
        const enrichedTeam = playerNFTs.map((nft) => {
          const meta = team.find((t) => t.id === nft.id);
          const position = meta?.position || "front";
          const role = getRoleFromPosition(nft, position);

          return {
            ...nft,
            position,
            role,
          };
        });

        // Map socket ke user ID untuk disconnection handling
        socketToUserMap.set(socket.id, userId);

        // Get user info untuk username (non-blocking)
        let username = userId; // default ke userId jika query gagal
        try {
          const { data: userData, error: usernameError } = await supabase
            .from("users")
            .select("username")
            .eq("account_address", userId)
            .single();

          if (!usernameError && userData?.username) {
            username = userData.username;
          }
        } catch (err) {
          // Continue dengan userId sebagai fallback
        }

        // Simpan ke waiting room dengan lastHeartbeat (HANYA untuk CREATE mode)
        const now = Date.now();
        const isCreator = matchMode === "create"; // PENTING: Tentukan isCreator berdasarkan matchMode
        
        // PENTING: Hanya tambahkan ke cache jika matchMode === "create"
        // Untuk "join" mode, user ditambahkan ke cache HANYA saat JOIN_ROOM dipanggil
        if (matchMode === "create") {
          waitingRoomsCache.set(userId, {
            userId,
            username,
            battleMode,
            team: enrichedTeam,
            joinedAt: now,
            lastHeartbeat: now, // Track last activity - immediately set on creation
            matchMode, // Store matchMode untuk digunakan nanti
            isCreator, // Set isCreator: true untuk create
          });
        }

        // Emit unified ROOM_UPDATE ke player (team_selected status)
        socket.emit("ROOM_UPDATE", {
          status: "team_selected",
          userId,
          battleMode,
          team: enrichedTeam,
          matchMode,
          isCreator, // Infokan ke frontend tentang creator status
          message: "Team selected successfully"
        });

        if (matchMode === "create") {
          // CREATE MODE: User adalah room creator dan menunggu opponent yang join ke room mereka
          socket.emit("ROOM_UPDATE", {
            status: "waiting",
            message: "Waiting for opponent to join your room...",
            battleMode,
            matchMode,
            isCreator: true, // Explicitly mark as creator
            roomOwnerId: userId,
          });

          // Broadcast ke potential opponents tentang room baru
          io.of("/pvp").emit("ROOM_UPDATE", {
            status: "new_opponent_available",
            battleMode,
            opponentId: userId,
            opponentUsername: username,
            timestamp: now,
          });
        } else if (matchMode === "join") {
          // JOIN MODE: User siap untuk join available opponents (USER BUKAN CREATOR)
          // PENTING: Jangan tambahkan ke cache di sini - user akan ditambahkan saat JOIN_ROOM dipanggil
          socket.emit("ROOM_UPDATE", {
            status: "waiting",
            message: "Team selected! Ready to join available opponents...",
            battleMode,
            matchMode,
            isCreator: false, // Explicitly mark as joiner
          });
        }
      } catch (err: any) {
        console.error("Error in SELECT_TEAM_PVP:", err.message);
        socket.emit("ROOM_UPDATE", { 
          error: "Failed to select team",
          resetState: true 
        });
      }
    }
  );

  /**
   * =========================================
   * JOIN ROOM - Dari challenge modal
   * Player 2 join ke room yang sudah di-create oleh player 1
   * Flow: Challenge diterima -> Player 2 select team -> Player 2 join room creator
   * =========================================
   */
  socket.on(
    "JOIN_ROOM",
    async ({
      userId,
      roomOwnerId,
      battleMode,
      team,
    }: {
      userId: string;
      roomOwnerId: string;
      battleMode: "alpha" | "team";
      team: { id: number; position: string }[];
    }) => {
      try {
        // PENTING: Check if user already has an active room (prevent double booking)
        const userExistingRoom = waitingRoomsCache.get(userId);
        if (userExistingRoom) {
          console.warn(
            "[JOIN_ROOM] User already has an active room",
            { userId, existingMode: userExistingRoom.matchMode }
          );
          socket.emit("ROOM_UPDATE", {
            error: "You are already in a room. Please cancel your current room first.",
            resetState: false,
          });
          return;
        }

        // Validasi team composition
        const validation = validateTeamComposition(team, battleMode);
        if (!validation.valid) {
          console.warn("[JOIN_ROOM] Validation failed:", validation.error);
          socket.emit("ROOM_UPDATE", {
            error: validation.error,
            resetState: true,
          });
          return;
        }

        // Fetch player NFTs untuk joiner
        const selectedNFTIds = team.map((t) => t.id);
        const playerNFTs = await getPlayerNFTs(userId, selectedNFTIds);

        if (!playerNFTs || playerNFTs.length === 0) {
          console.error("[JOIN_ROOM] No valid NFTs found for:", {
            userId,
            selectedNFTIds,
          });
          socket.emit("ROOM_UPDATE", {
            error: "No valid NFTs found",
            resetState: true,
          });
          return;
        }

        // Enrich team dengan role dari position
        const enrichedTeam = playerNFTs.map((nft) => {
          const meta = team.find((t) => t.id === nft.id);
          const position = meta?.position || "front";
          const role = getRoleFromPosition(nft, position);

          return {
            ...nft,
            position,
            role,
          };
        });

        // Map socket ke user ID
        socketToUserMap.set(socket.id, userId);

        // Get username untuk joiner
        let username = userId;
        try {
          const { data: userData, error: usernameError } = await supabase
            .from("users")
            .select("username")
            .eq("account_address", userId)
            .single();

          if (!usernameError && userData?.username) {
            username = userData.username;
          }
        } catch (err) {
          // Continue dengan userId sebagai fallback
        }

        // Save joiner's room ke cache
        const now = Date.now();
        waitingRoomsCache.set(userId, {
          userId,
          username,
          battleMode,
          team: enrichedTeam,
          joinedAt: now,
          lastHeartbeat: now,
          matchMode: "join", // Joiner adalah dalam mode join
          isCreator: false, // PENTING: Joiner TIDAK PERNAH creator, ALWAYS false di JOIN_ROOM
        });

        // Get room owner's info
        const roomOwnerRoom = waitingRoomsCache.get(roomOwnerId);

        if (!roomOwnerRoom) {
          socket.emit("ROOM_UPDATE", {
            error: "Room owner is no longer available",
            resetState: true,
          });
          return;
        }

        if (roomOwnerRoom.battleMode !== battleMode) {
          socket.emit("ROOM_UPDATE", {
            error: "Battle mode mismatch with room owner",
            resetState: true,
          });
          return;
        }

        // PENTING: Check if room owner already has a matched opponent
        if (roomOwnerRoom.matchedOpponentId) {
          console.warn(
            "[JOIN_ROOM] Room owner already has a matched opponent",
            { roomOwnerId, existingOpponent: roomOwnerRoom.matchedOpponentId }
          );
          socket.emit("ROOM_UPDATE", {
            error: "This room already has an opponent. Please select another room.",
            resetState: true,
          });
          return;
        }

        // Connect both players - save opponent info
        roomOwnerRoom.matchedOpponentId = userId;
        roomOwnerRoom.opponentTeam = enrichedTeam;

        // Emit ROOM_UPDATE to joiner - opponent joined
        // PENTING: isCreator SELALU false untuk joiner
        socket.emit("ROOM_UPDATE", {
          status: "opponent_ready",
          isCreator: false, // Joiner tidak pernah creator
          opponentId: roomOwnerId,
          opponent: {
            userId: roomOwnerId,
            username: roomOwnerRoom.username,
            team: roomOwnerRoom.team,
          },
          message: "Successfully joined room! Waiting for room creator to start battle...",
        });

        // Send ROOM_UPDATE to room owner - opponent joined
        // PENTING: isCreator SELALU true untuk room owner/creator
        let roomOwnerSocketId: string | null = null;
        for (const [socketId, userId_] of socketToUserMap.entries()) {
          if (userId_ === roomOwnerId) {
            roomOwnerSocketId = socketId;
            break;
          }
        }

        if (roomOwnerSocketId) {
          io.of("/pvp").to(roomOwnerSocketId).emit("ROOM_UPDATE", {
            status: "opponent_ready",
            isCreator: true, // Room owner/creator ALWAYS true
            opponentId: userId,
            opponent: {
              userId: userId,
              username: username,
              team: enrichedTeam,
            },
            message: "An opponent has joined your challenge! Ready to start battle?",
          });
        } else {
          console.error(`[JOIN_ROOM] Could not find socket for room owner (${roomOwnerId})`);
        }
      } catch (err: any) {
        console.error("Error in JOIN_ROOM:", err.message);
        socket.emit("ROOM_UPDATE", {
          error: "Failed to join room",
          resetState: true,
        });
      }
    }
  );

  /**
   * =========================================
   * MANUAL JOIN/ACCEPT OPPONENT
   * Player 2 joins room, then wait for confirmation from room creator (player 1)
   * =========================================
   */
  socket.on(
    "ACCEPT_OPPONENT",
    async ({
      userId,
      opponentId,
      battleMode,
    }: {
      userId: string;
      opponentId: string;
      battleMode: "alpha" | "team";
    }) => {
      try {
        // PENTING: Check if both rooms still exist (they may have expired/disconnected)
        const player2Room = waitingRoomsCache.get(userId);
        const player1Room = waitingRoomsCache.get(opponentId);

        if (!player2Room) {
          socket.emit("ROOM_UPDATE", {
            error: "Your team selection was not saved. Please select team again.",
            resetState: true
          });
          return;
        }

        if (!player1Room) {
          socket.emit("ROOM_UPDATE", {
            error: "Opponent no longer available - they may have left or accepted another challenge",
            resetState: true
          });
          return;
        }

        if (player1Room.battleMode !== player2Room.battleMode) {
          socket.emit("ROOM_UPDATE", {
            error: "Battle mode mismatch",
            resetState: true
          });
          return;
        }

        // PENTING: Check if player1 already has another matched opponent
        if (player1Room.matchedOpponentId && player1Room.matchedOpponentId !== userId) {
          console.warn(
            "[ACCEPT_OPPONENT] Player 1 already has another matched opponent",
            { player1: opponentId, existingMatch: player1Room.matchedOpponentId }
          );
          socket.emit("ROOM_UPDATE", {
            error: "Opponent has already accepted another challenge. Please select another opponent.",
            resetState: true
          });
          return;
        }

        // PENTING: Check if player2 already has another matched opponent
        if (player2Room.matchedOpponentId && player2Room.matchedOpponentId !== opponentId) {
          console.warn(
            "[ACCEPT_OPPONENT] Player 2 already has another matched opponent",
            { player2: userId, existingMatch: player2Room.matchedOpponentId }
          );
          socket.emit("ROOM_UPDATE", {
            error: "You are already matched with another opponent. Cannot accept multiple challenges.",
            resetState: true
          });
          return;
        }

        // Save opponent info to both rooms
        player1Room.matchedOpponentId = userId;
        player1Room.opponentTeam = player2Room.team;
        
        player2Room.matchedOpponentId = opponentId;
        player2Room.opponentTeam = player1Room.team;

        // Emit unified ROOM_UPDATE to player 2 (requester) - current socket
        // PENTING: player2 SELALU isCreator=false (joiner)
        socket.emit("ROOM_UPDATE", {
          status: "opponent_ready",
          isCreator: false, // Player 2 adalah joiner
          opponentId: opponentId,
          opponent: {
            userId: opponentId,
            username: player1Room.username,
            team: player1Room.team,
          },
          message: "Your request was accepted. Waiting for room creator to start battle...",
        });

        // Send unified ROOM_UPDATE to player 1 (room creator)
        // Find player 1's socket using socketToUserMap - reverse lookup
        // PENTING: player1 SELALU isCreator=true (creator)
        let player1SocketId: string | null = null;
        for (const [socketId, userId_] of socketToUserMap.entries()) {
          if (userId_ === opponentId) {
            player1SocketId = socketId;
            break;
          }
        }

        if (player1SocketId) {
          io.of("/pvp").to(player1SocketId).emit("ROOM_UPDATE", {
            status: "opponent_ready",
            isCreator: true, // Player 1 adalah creator
            opponentId: userId,
            opponent: {
              userId: userId,
              username: player2Room.username,
              team: player2Room.team,
            },
            message: "An opponent has joined! Click START to begin the battle.",
          });
        } else {
          console.error(`[ACCEPT_OPPONENT] Could not find socket for player 1 (${opponentId})`);
        }
      } catch (err: any) {
        console.error("Error in ACCEPT_OPPONENT:", err.message);
        socket.emit("ROOM_UPDATE", { 
          error: "Failed to accept opponent",
          resetState: true 
        });
      }
    }
  );

  /**
   * =========================================
   * START BATTLE - Only room creator (player 1) can start
   * Triggered when room creator clicks START button after opponent joins
   * =========================================
   */
  socket.on(
    "START_BATTLE",
    async ({
      userId,
      battleMode,
    }: {
      userId: string;
      battleMode: "alpha" | "team";
    }) => {
      try {
        const playerRoom = waitingRoomsCache.get(userId);

        if (!playerRoom) {
          socket.emit("ROOM_UPDATE", { 
            error: "Room not found",
            resetState: true 
          });
          return;
        }

        // PENTING: HANYA room creator (isCreator=true) yang boleh start battle
        if (!playerRoom.isCreator) {
          socket.emit("ROOM_UPDATE", {
            error: "Only room creator can start the battle. Please wait for room creator to start.",
            resetState: false
          });
          console.warn(`[START_BATTLE] Non-creator user (${userId}) attempted to start battle. Rejected.`);
          return;
        }

        if (!playerRoom.matchedOpponentId) {
          socket.emit("ROOM_UPDATE", {
            error: "No opponent has joined yet. Please wait for opponent.",
          });
          return;
        }

        if (!playerRoom.opponentTeam) {
          socket.emit("ROOM_UPDATE", {
            error: "Opponent team not found. Please wait for opponent.",
          });
          return;
        }

        // Get opponent room
        const opponentRoom = waitingRoomsCache.get(
          playerRoom.matchedOpponentId
        );

        if (!opponentRoom) {
          socket.emit("ROOM_UPDATE", { 
            error: "Opponent room not found",
            resetState: true 
          });
          return;
        }

        // Send confirmation to opponent (joiner) before starting battle
        // So both players see "Ready to Battle" state
        let player2SocketId: string | null = null;
        for (const [socketId, userId_] of socketToUserMap.entries()) {
          if (userId_ === playerRoom.matchedOpponentId) {
            player2SocketId = socketId;
            break;
          }
        }

        if (player2SocketId) {
          io.of("/pvp")
            .to(player2SocketId)
            .emit("ROOM_UPDATE", {
              status: "opponent_confirmed",
              message: "Room creator confirmed! Ready to battle!",
            });
        } else {
          console.error(`[START_BATTLE] Could not find socket for player 2 (${playerRoom.matchedOpponentId})`);
        }

        // Start the battle
        startPVPBattle(
          socket,
          io,
          userId,
          playerRoom.team,
          playerRoom.matchedOpponentId,
          playerRoom.opponentTeam,
          battleMode,
          player2SocketId // Pass player 2 socket ID
        );
      } catch (err: any) {
        console.error("Error in START_BATTLE:", err.message);
        socket.emit("ROOM_UPDATE", { 
          error: "Failed to start battle",
          resetState: true 
        });
      }
    }
  );

  /**
   * =========================================
   * START BATTLE (INTERNAL)
   * =========================================
   */
  async function startPVPBattle(
    socket: any,
    io: any,
    player1Id: string,
    player1Team: any,
    player2Id: string,
    player2Team: any,
    battleMode: "alpha" | "team",
    player2SocketId?: string | null
  ) {
    try {
      // Validate team data - ensure all NFTs have required attributes
      const validateTeamData = (team: any[]) => {
        return team.every(
          (nft) =>
            nft &&
            typeof nft.hp === "number" &&
            typeof nft.atk === "number" &&
            typeof nft.spd === "number" &&
            typeof nft.def === "number"
        );
      };

      if (!validateTeamData(player1Team) || !validateTeamData(player2Team)) {
        console.error(
          "[startPVPBattle] Invalid team data - missing attributes",
          {
            player1Team,
            player2Team,
          }
        );
        socket.emit("ROOM_UPDATE", {
          error: "Team data is incomplete. Some NFTs are missing attributes.",
          resetState: true
        });
        return;
      }

      const battleId = `pvp_${battleMode}_${player1Id}_${player2Id}_${Date.now()}`;

      // Determine first turn player
      const firstTurnPlayerId = determineFirstTurn(player1Id, player2Id);

      const battle = {
        battleId,
        battleMode,
        player1Id,
        player2Id,
        player1Team,
        player2Team,
        firstTurnPlayerId,
        status: "in_progress" as const,
        createdAt: Date.now(),
      };

      activeBattlesCache.set(battleId, battle);

      // IMPORTANT: Remove both players from waiting room cache
      // Mereka sudah masuk battle, jadi tidak perlu di cache waiting rooms lagi
      waitingRoomsCache.delete(player1Id);
      waitingRoomsCache.delete(player2Id);

      // IMPORTANT: Join player 1's socket to battleId room
      socket.join(battleId);

      // Prepare battle started payload
      const battleStartedPayload = {
        status: "battle_started",
        battleId,
        battleMode,
        player1Id,
        player2Id,
        player1Team,
        player2Team,
        firstTurnPlayerId,
      };

      // Send to player 1 (room creator)
      socket.emit("ROOM_UPDATE", battleStartedPayload);

      // Send to player 2 (opponent joiner) - if socket ID found
      if (player2SocketId) {
        // Join player 2 to battleId room
        const player2Socket = io.of("/pvp").sockets.get(player2SocketId);
        if (player2Socket) {
          player2Socket.join(battleId);
          io.of("/pvp").to(player2SocketId).emit("ROOM_UPDATE", battleStartedPayload);
        }
      } else {
        console.warn(`[startPVPBattle] Player 2 socket ID not provided, trying to find it...`);
        // Fallback: try to find socket ID
        let foundSocketId: string | null = null;
        for (const [socketId, userId_] of socketToUserMap.entries()) {
          if (userId_ === player2Id) {
            foundSocketId = socketId;
            break;
          }
        }
        if (foundSocketId) {
          const player2Socket = io.of("/pvp").sockets.get(foundSocketId);
          if (player2Socket) {
            player2Socket.join(battleId);
            io.of("/pvp").to(foundSocketId).emit("ROOM_UPDATE", battleStartedPayload);
          }
        } else {
          console.error(`[startPVPBattle] Could not find socket for player 2 (${player2Id})`);
        }
      }

      // Insert battle record
      await supabase.from("pvp_battles").insert([
        {
          battle_id: battleId,
          battle_mode: battleMode,
          player1_id: player1Id,
          player2_id: player2Id,
          player1_team: player1Team,
          player2_team: player2Team,
          first_turn_player_id: firstTurnPlayerId,
          status: "in_progress",
        },
      ]);

      // Start simulation
      simulateRealtimePVPBattle(battle, io);
    } catch (err: any) {
      console.error("Error starting PVP battle:", err.message);
      socket.emit("ROOM_UPDATE", { 
        error: "Failed to start battle",
        resetState: true 
      });
    }
  }

  /**
   * =========================================
   * CANCEL WAITING - User membatalkan waiting room
   * Menghapus room dari cache dan notify broadcast
   * PENTING: Clean up both user's room AND matched opponent's room
   * =========================================
   */
  socket.on("CANCEL_WAITING", (userId: string) => {
    try {
      const room = waitingRoomsCache.get(userId);

      if (room) {
        // PENTING: If user has matched opponent, clean opponent's matched reference too
        if (room.matchedOpponentId) {
          const opponentRoom = waitingRoomsCache.get(room.matchedOpponentId);
          if (opponentRoom) {
            // Clear opponent's matched reference
            opponentRoom.matchedOpponentId = undefined;
            opponentRoom.opponentTeam = undefined;

            // Notify opponent yang telah di-matched
            let opponentSocketId: string | null = null;
            for (const [socketId, userId_] of socketToUserMap.entries()) {
              if (userId_ === room.matchedOpponentId) {
                opponentSocketId = socketId;
                break;
              }
            }

            if (opponentSocketId) {
              io.of("/pvp").to(opponentSocketId).emit("ROOM_UPDATE", {
                status: "opponent_cancelled",
                message: "Matched opponent cancelled the room",
                resetState: true,
              });
            }
          }
        }

        // Delete room dari cache
        waitingRoomsCache.delete(userId);

        // Unified broadcast dengan ROOM_UPDATE
        io.of("/pvp").emit("ROOM_UPDATE", {
          status: "room_cancelled",
          userId,
          battleMode: room.battleMode,
          message: `Opponent room (${room.username}) has been cancelled`,
        });
      }

      // Emit confirmation ke client
      socket.emit("ROOM_UPDATE", {
        status: "waiting_cancelled",
        message: "Waiting cancelled successfully",
      });
    } catch (err: any) {
      console.error("Error in CANCEL_WAITING:", err.message);
      socket.emit("ROOM_UPDATE", { 
        error: "Failed to cancel waiting",
        resetState: false 
      });
    }
  });

  /**
   * =========================================
   * REJOIN BATTLE
   * =========================================
   */
  socket.on("REJOIN_BATTLE_PVP", async (battleId: string) => {
    try {
      const battle = activeBattlesCache.get(battleId);

      if (battle) {
        socket.join(battleId);
        console.log("[REJOIN_BATTLE_PVP] Battle found in cache:", { battleId, status: battle.status });
        
        socket.emit("BATTLE_REJOINED", {
          battleId,
          status: battle.status,
          player1Id: battle.player1Id,
          player2Id: battle.player2Id,
          player1Progress: 100,
          player2Progress: 100,
          player1Team: battle.player1Team,
          player2Team: battle.player2Team,
        });
        return;
      }

      // Fetch dari database jika battle sudah finished
      const { data } = await supabase
        .from("pvp_battles")
        .select("*")
        .eq("battle_id", battleId)
        .single();

      if (data) {
        console.log("[REJOIN_BATTLE_PVP] Battle found in database:", { battleId, status: data.status });
        socket.emit("BATTLE_FINISHED", {
          battleId,
          status: data.status,
          winner: data.winner_id,
          player1Progress: data.final_player1_progress || 0,
          player2Progress: data.final_player2_progress || 0,
          player1Team: data.player1_team,
          player2Team: data.player2_team,
        });
      }
    } catch (err: any) {
      console.error("Error in REJOIN_BATTLE_PVP:", err.message);
    }
  });

  /**
   * =========================================
   * LEAVE BATTLE - Jika player disconnect
   * =========================================
   */
  socket.on("LEAVE_BATTLE_PVP", (battleId: string) => {
    socket.leave(battleId);
  });

  /**
   * =========================================
   * CLEANUP ON DISCONNECT
   * Pastikan waiting room dihapus jika user disconnect
   * PENTING: Clean up both user's room AND matched opponent's room
   * =========================================
   */
  socket.on("disconnect", () => {
    try {
      const userId = socketToUserMap.get(socket.id);
      if (userId) {
        // Delete waiting room jika ada
        const room = waitingRoomsCache.get(userId);
        if (room) {
          // PENTING: If user has matched opponent, clean opponent's matched reference too
          if (room.matchedOpponentId) {
            const opponentRoom = waitingRoomsCache.get(room.matchedOpponentId);
            if (opponentRoom) {
              // Clear opponent's matched reference
              opponentRoom.matchedOpponentId = undefined;
              opponentRoom.opponentTeam = undefined;

              // Notify opponent yang telah di-matched
              let opponentSocketId: string | null = null;
              for (const [socketId, userId_] of socketToUserMap.entries()) {
                if (userId_ === room.matchedOpponentId) {
                  opponentSocketId = socketId;
                  break;
                }
              }

              if (opponentSocketId) {
                io.of("/pvp").to(opponentSocketId).emit("ROOM_UPDATE", {
                  status: "opponent_disconnected",
                  message: "Your matched opponent disconnected",
                  resetState: true,
                });
              }
            }
          }

          waitingRoomsCache.delete(userId);
          console.log(
            "[DISCONNECT] Cleaned up waiting room for user:",
            userId
          );

          // Notify other players about disconnection
          io.of("/pvp").emit("ROOM_UPDATE", {
            status: "room_cancelled",
            userId,
            battleMode: room.battleMode,
            message: `Opponent (${room.username}) has disconnected`,
          });
        }
        socketToUserMap.delete(socket.id);
      }
    } catch (err: any) {
      console.error("Error in disconnect handler:", err.message);
    }
  });
}
