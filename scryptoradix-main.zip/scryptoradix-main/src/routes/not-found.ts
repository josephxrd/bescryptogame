import { Hono } from 'hono';

export const notFoundRoute = new Hono();

notFoundRoute.all('*', (c) => {
  return c.json({ error: 'Route not found' }, 404);
});