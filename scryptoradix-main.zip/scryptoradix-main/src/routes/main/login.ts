import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

export const loginRoute = new Hono();

loginRoute.post('/login', async (c) => {
  try {
    const { email, password } = await c.req.json();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      return c.json({ error: error.message }, 400);
    }
    return c.json({ session: data.session, user: data.user });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});
