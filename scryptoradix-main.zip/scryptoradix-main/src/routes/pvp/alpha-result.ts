import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/alpha/battle/:battleId/result
 * Ambil hasil final dari alpha battle
 */
route.get('/battle/:battleId/result', async (c) => {
  try {
    const battleId = c.req.param('battleId');

    if (!battleId) {
      return c.json({ error: 'Missing battleId parameter' }, 400);
    }

    // Ambil data battle
    const { data: battle, error: battleError } = await supabase
      .from('pvp_battles')
      .select('*')
      .eq('battle_id', battleId)
      .single();

    if (battleError || !battle) {
      return c.json({ error: 'Battle not found' }, 404);
    }

    // Ambil semua logs
    const { data: logs, error: logsError } = await supabase
      .from('pvp_battle_logs')
      .select('*')
      .eq('battle_id', battleId)
      .order('timestamp', { ascending: true });

    if (logsError) throw logsError;

    // Determine result status (win/lose/draw)
    const player1Address = battle.player1_id;
    const player2Address = battle.player2_id;
    const winnerId = battle.winner_id;
    const resultStatus = winnerId === player1Address ? 'win' : winnerId === player2Address ? 'lose' : 'draw';

    return c.json({
      battleId: battle.battle_id,
      battleMode: battle.battle_mode,
      winner: battle.winner_id,
      loser: battle.loser_id,
      player1Address,
      player2Address,
      player1Team: battle.player1_team,
      player2Team: battle.player2_team,
      player1Progress: battle.final_player1_progress,
      player2Progress: battle.final_player2_progress,
      status: resultStatus,
      createdAt: battle.created_at,
      logs: logs || [],
      rewards: {
        gold: resultStatus === 'win' ? 200 : 50,
        experience: resultStatus === 'win' ? 20 : 5,
        nftExp: resultStatus === 'win' ? 50 : 10,
      },
    });
  } catch (error: any) {
    console.error('Error fetching battle result:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;