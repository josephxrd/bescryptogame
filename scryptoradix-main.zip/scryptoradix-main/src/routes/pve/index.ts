import { Hono } from 'hono';
import battleProgressRoute from './battle-progress.js';
import battleResultRoute from './battle-result.js';
import battleStartRoute from './battle-start.js';
import battleStatisticRoute from './battle-statistic.js';
import levelAreaRoute from './level-area.js';
import levelRoute from './level.js';

export const pveRoute = new Hono();

// Home route
pveRoute.get('/', async (c) => {
  try {
    return c.json({ message: 'PvE Mode Home' });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Mount sub-routes
pveRoute.route('/', battleProgressRoute);
pveRoute.route('/', battleResultRoute);
pveRoute.route('/', battleStartRoute);
pveRoute.route('/', battleStatisticRoute);
pveRoute.route('/', levelAreaRoute);
pveRoute.route('/', levelRoute);