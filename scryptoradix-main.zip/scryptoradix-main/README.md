```
pnpm install
pnpm dev
```

```
$BROWSER http://localhost:3000
```

## API Endpoints

### Main
- `GET /api/` — Home
- `POST /api/auth/login` — Login
- `GET /api/profile` — Profile
- `GET /api/collection` — Collection
- `GET /api/leaderboard` — Leaderboard
- `GET /api/achievements` — Achievements

### User
- `GET /api/user/:id` — Get user by ID
- `POST /api/user/login` — User login
- `POST /api/user/register` — User register

### Auth
- `POST /api/wallet/connect` — Connect wallet
- `POST /api/wallet/disconnect` — Disconnect wallet

### PvE
- `GET /api/pve/` — PvE Home
- `GET /api/pve/battle/:battleId/progress` — Battle progress
- `GET /api/pve/battle/:battleId/result` — Battle result
- `POST /api/pve/battle/start` — Start battle
- `GET /api/pve/battle/:battleId/statistics` — Battle statistics
- `GET /api/pve/level/:id/area/:areaId` — Level area
- `GET /api/pve/level/:id` — Level detail

### PvP
- `GET /api/pvp/` — PvP Home
- `GET /api/pvp/challenge/:challengeId` — Challenge info
- `POST /api/pvp/select-nft` — Select NFT
- `POST /api/pvp/select-team` — Select team

#### PvP Alpha
- `GET /api/pvp/alpha/battle/:battleId/progress` — Alpha battle progress
- `POST /api/pvp/alpha/battle/start` — Start alpha battle
- `GET /api/pvp/alpha/battle/:battleId/result` — Alpha battle result
- `GET /api/pvp/alpha/matches` — Alpha match selection
- `GET /api/pvp/alpha/battle/:battleId/stats/defeat` — Alpha defeat statistics
- `GET /api/pvp/alpha/battle/:battleId/stats/victory` — Alpha victory statistics

#### PvP Team
- `GET /api/pvp/team/battle/:battleId/progress` — Team battle progress
- `POST /api/pvp/team/battle/start` — Start team battle
- `GET /api/pvp/team/battle/:battleId/result` — Team battle result
- `GET /api/pvp/team/matches` — Team match selection
- `GET /api/pvp/team/battle/:battleId/stats/defeat` — Team defeat statistics
- `GET /api/pvp/team/battle/:battleId/stats/victory` — Team victory statistics

### Not Found
- Semua endpoint lain akan mengembalikan `{ error: 'Route not found' }` dengan status 404.