import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * POST /pvp/team/battle/start
 * Start team (3v3) battle via socket.io SELECT_TEAM_PVP event
 * This is just documentation endpoint
 */
route.post('/battle/start', async (c) => {
  try {
    const { userId, nftIds } = await c.req.json();

    // Validate required fields
    if (!userId) {
      return c.json({ error: 'Missing userId' }, 400);
    }

    if (!nftIds || !Array.isArray(nftIds)) {
      return c.json({ error: 'nftIds must be an array' }, 400);
    }

    // Validate exactly 3 NFTs
    if (nftIds.length !== 3) {
      return c.json(
        {
          error: `Team must have exactly 3 NFTs, got ${nftIds.length}`,
        },
        400
      );
    }

    // Validate NFT ownership - get all 3 NFTs
    const { data: nfts, error } = await supabase
      .from('nfts')
      .select('id, name, role, level, hp, atk, def, spd')
      .in('id', nftIds)
      .eq('owner_account', userId);

    if (error) {
      console.error('[NFT Query Error]', error);
      return c.json({ error: 'Database error' }, 500);
    }

    if (!nfts || nfts.length !== 3) {
      return c.json(
        {
          error: `Invalid NFTs or not owned by user. Found ${nfts?.length || 0} NFT(s), expected 3`,
        },
        404
      );
    }

    // Verify all IDs match
    const foundIds = nfts.map((n) => n.id).sort();
    const requestedIds = nftIds.sort();
    const allIdsMatch = foundIds.every((id, idx) => id === requestedIds[idx]);

    if (!allIdsMatch) {
      return c.json({ error: 'One or more NFTs not found or not owned by user' }, 404);
    }

    console.log(`[Team Battle Start] User: ${userId}, NFTs: ${nftIds.join(',')}`);

    return c.json({
      success: true,
      message: 'Connect to socket.io /pvp namespace to start team battle',
      socketEvent: 'SELECT_TEAM_PVP',
      payload: {
        userId,
        battleMode: 'team',
        team: nfts.map((nft, idx) => ({
          id: nft.id,
          position: idx === 0 ? 'back' : idx === 1 ? 'mid' : 'front',
        })),
      },
      selectedNFTs: nfts,
      teamSize: nfts.length,
    });
  } catch (error: any) {
    console.error('[Team Battle Start Error]:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;