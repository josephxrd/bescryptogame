// modules/pve/battle.handlers.ts
import { activeBattlesCache } from "./cache.js";
import { getPlayerNFTs, getBotNFTs } from "./nft.service.js";
import {
  simulateRealtimeBattle,
  skipBattleProgress,
} from "./battle.simulation.js";
import { supabase } from "../../lib/supabase.js";

export function registerBattleHandlers(socket: any, io: any) {
  /**
   * =========================================
   * START BATTLE (UPDATED FOR NEW FE FORMAT)
   * =========================================
   */
  socket.on(
    "START_BATTLE",
    async ({
      levelId,
      userId,
      team,
    }: {
      levelId: number;
      userId: string;
      team: { id: number; role: string; position: string }[];
    }) => {
      try {
        if (!team || !Array.isArray(team) || team.length === 0) {
          socket.emit("ERROR", { message: "No team provided" });
          return;
        }

        const selectedNFTIds = team.map((t) => t.id);

        const playerTeam = await getPlayerNFTs(userId, selectedNFTIds);
        if (!playerTeam.length) {
          socket.emit("ERROR", { message: "No valid player NFTs found" });
          return;
        }

        const rolePositionMap: Record<string, string> = {
          frontline: "front",
          attacker: "mid",
          backline: "back",
        };

        const getRoleFromPosition = (pos: string) => {
          const entry = Object.entries(rolePositionMap).find(
            ([_, mapped]) => mapped === pos
          );
          return entry ? entry[0] : "frontline";
        };

        // === FINAL ROLE/POS TEAM ===
        const playerTeamWithPos = playerTeam.map((nft) => {
          const meta = team.find((t) => t.id === nft.id);
          const position = meta?.position || "front";
          const role =
            nft.role && nft.role.trim() !== ""
              ? nft.role
              : getRoleFromPosition(position);

          return {
            ...nft,
            position,
            role,
          };
        });

        const enemyTeam = await getBotNFTs(levelId);
        if (!enemyTeam.length) {
          socket.emit("ERROR", { message: "Enemy team not found" });
          return;
        }

        const battleId = `${userId}_${Date.now()}`;

        const battle = {
          battleId,
          userId,
          levelId,
          selectedNFTIds,
          playerTeam: playerTeamWithPos, // IMPORTANT
          enemyTeam,
          status: "in_progress",
        };

        activeBattlesCache.set(battleId, battle);
        socket.join(battleId);

        await supabase.from("pve_battles").insert([
          {
            battle_id: battleId,
            user_id: userId,
            level_id: levelId,
            player_team: playerTeamWithPos,
            enemy_team: enemyTeam,
            status: "in_progress",
          },
        ]);

        socket.emit("BATTLE_STARTED", { battleId });

        simulateRealtimeBattle(battle, io);
      } catch (err: any) {
        console.error("Error starting battle:", err.message);
        socket.emit("ERROR", { message: "Failed to start battle" });
      }
    }
  );

  /**
   * =========================================
   * REJOIN BATTLE
   * =========================================
   */
  socket.on("REJOIN_BATTLE", async (battleId: string) => {
    const battle = activeBattlesCache.get(battleId);

    if (battle) {
      socket.join(battleId);
      socket.emit("BATTLE_REJOINED", {
        battleId,
        status: battle.status || "in_progress",
      });
      return;
    }

    const { data } = await supabase
      .from("pve_battles")
      .select("*")
      .eq("battle_id", battleId)
      .single();

    if (data) {
      socket.emit("BATTLE_FINISHED", { battleId, status: data.status });
    }
  });

  /**
   * =========================================
   * SKIP BATTLE
   * =========================================
   */
  socket.on("SKIP_BATTLE", async (battleId: string) => {
    try {
      const battle = activeBattlesCache.get(battleId);

      if (!battle) {
        socket.emit("ERROR", {
          message: "Battle not found or already finished",
        });
        return;
      }

      const result = await skipBattleProgress(battle);
      activeBattlesCache.delete(battleId);

      socket.emit("BATTLE_SKIPPED", { battleId, ...result });
    } catch (err: any) {
      console.error("Error skipping battle:", err.message);
      socket.emit("ERROR", { message: "Failed to skip battle" });
    }
  });

  /**
   * =========================================
   * GET BATTLE STATUS
   * =========================================
   */
  socket.on("GET_BATTLE_STATUS", async (battleId: string) => {
    const battle = activeBattlesCache.get(battleId);

    if (battle) {
      socket.emit("BATTLE_STATUS", battle);
      return;
    }

    const { data } = await supabase
      .from("pve_battles")
      .select("*")
      .eq("battle_id", battleId)
      .single();

    socket.emit("BATTLE_STATUS", data);
  });

  /**
   * =========================================
   * LEAVE BATTLE
   * =========================================
   */
  socket.on("LEAVE_BATTLE", (battleId: string) => socket.leave(battleId));
}
