import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/team/matches
 * List pemain yang menunggu match untuk team (3v3)
 */
route.get('/matches', async (c) => {
  try {
    const userId = c.req.query('userId');

    if (!userId) {
      return c.json({ error: 'Missing userId parameter' }, 400);
    }

    // Ambil daftar recent team matches
    const { data: matches, error } = await supabase
      .from('pvp_battles')
      .select(
        `id, 
         battle_id, 
         battle_mode,
         player1_id, 
         player2_id, 
         winner_id,
         created_at,
         status`
      )
      .eq('battle_mode', 'team')
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) throw error;

    return c.json({
      mode: 'team',
      totalMatches: matches?.length || 0,
      matches: matches || [],
      instructions: 'Use socket.io SELECT_TEAM_PVP event with 3 NFTs to start matchmaking',
    });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;