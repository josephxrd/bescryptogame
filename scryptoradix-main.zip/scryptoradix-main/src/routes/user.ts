import { Hono } from "hono";
import { supabase } from "../lib/supabase.js";
import { getRadixURL } from "../utils/radixNetwork.js";

export const userRoute = new Hono();

// 🧪 Set ke true jika ingin testing (NFT akan kosong)
const TEST_MODE = false;

// Base URL Radix (mainnet / stokenet)
const RADIX = getRadixURL();

/* =====================================
   🟩 GET user by account_address
===================================== */
userRoute.post("/check", async (c) => {
  const { account } = await c.req.json();

  try {
    // ============================================================
    // STEP 0: Fetch user from DB
    // ============================================================
    const { data: user, error: userError } = await supabase
      .from("users")
      .select("*")
      .eq("account_address", account)
      .maybeSingle();

    if (userError) {
      console.error("Fetch user error:", userError.message);
      return c.json({ error: "Failed to fetch user info" }, 500);
    }

    /* ============================================================
       STEP F: Fetch Fungible Token Balances
    ============================================================ */
    let fungibles: any[] = [];

    try {
      const fungibleRes = await fetch(`${RADIX}/state/entity/page/fungibles/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: account }),
      });

      if (!fungibleRes.ok) {
        const errorData = await fungibleRes.json();
        return c.json(errorData, fungibleRes.status as any);
      }

      const fungibleData = await fungibleRes.json();
      fungibles = fungibleData.items || [];
    } catch (err) {
      console.error("Fungible fetch error:", err);
      return c.json({ error: String(err) }, 500);
    }

    // ============================================================
    // STEP 1: Get all NFT resources
    // ============================================================
    const res1 = await fetch(`${RADIX}/state/entity/page/non-fungibles/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ address: account }),
    });

    if (!res1.ok) {
      const errorData = await res1.json();
      return c.json(errorData, res1.status as any);
    }

    const data1 = await res1.json();
    const resources = (data1.items || []) as { resource_address: string }[];

    if (!resources.length) {
      const { data: dbNFTs } = await supabase
        .from("nfts")
        .select("*")
        .eq("owner_account", account);

      return c.json({
        message: "No new NFTs found for this account",
        account,
        user: user || null,
        fungibles,
        total: TEST_MODE ? 0 : dbNFTs?.length || 0,
        nfts: TEST_MODE ? [] : dbNFTs || [],
      });
    }

    const nftResults: any[] = [];

    // ============================================================
    // STEP 2: Loop setiap NFT resource
    // ============================================================
    for (const resource of resources) {
      const resourceAddress = resource.resource_address;

      // Step 2a: ambil semua NFT IDs
      const res2 = await fetch(`${RADIX}/state/non-fungible/ids`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resource_address: resourceAddress }),
      });

      if (!res2.ok) {
        const errorData = await res2.json();
        return c.json(errorData, res2.status as any);
      }

      const data2 = await res2.json();
      const nftIds = data2.non_fungible_ids?.items || [];
      if (!nftIds.length) continue;

      // Step 2b: cek kepemilikan
      const resLoc = await fetch(`${RADIX}/state/non-fungible/location`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resource_address: resourceAddress,
          non_fungible_ids: nftIds,
        }),
      });

      if (!resLoc.ok) {
        const errorData = await resLoc.json();
        return c.json(errorData, resLoc.status as any);
      }

      const locData = await resLoc.json();
      const ownedNFTs = (locData.non_fungible_ids || []).filter(
        (n: any) =>
          n.owning_vault_global_ancestor_address === account && !n.is_burned,
      );

      if (!ownedNFTs.length) continue;

      const ownedNFTIds = ownedNFTs.map((n: any) => n.non_fungible_id);

      const res3 = await fetch(`${RADIX}/state/non-fungible/data`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resource_address: resourceAddress,
          non_fungible_ids: ownedNFTIds,
        }),
      });

      if (!res3.ok) {
        const errorData = await res3.json();
        return c.json(errorData, res3.status as any);
      }

      const data3 = await res3.json();
      const nfts = (data3.non_fungible_ids || []) as {
        non_fungible_id: string;
        data?: { programmatic_json?: { fields?: Field[] } };
      }[];

      type Field = { field_name: string; value: string | number | null };

      const nftIdsFull = nfts.map(
        (n) => `${resourceAddress}-${n.non_fungible_id}`,
      );

      const { data: existingNFTs, error: existingError } = await supabase
        .from("nfts")
        .select("id")
        .in("id", nftIdsFull);

      if (existingError) {
        return c.json({ error: existingError.message }, 500);
      }

      const existingIds = new Set(existingNFTs?.map((x) => x.id) || []);

      for (const nft of nfts) {
        const nftId = `${resourceAddress}-${nft.non_fungible_id}`;
        const fields = (nft.data?.programmatic_json?.fields || []) as Field[];

        const name = fields.find((f) => f.field_name === "name")?.value;
        const description = fields.find(
          (f) => f.field_name === "description",
        )?.value;
        const image = fields.find(
          (f) => f.field_name === "key_image_url",
        )?.value;

        const isExisting = existingIds.has(nftId);

        let nftPayload: any = {
          id: nftId,
          owner_account: account,
        };

        if (!isExisting) {
          nftPayload = {
            ...nftPayload,
            name: name || "Base NFT",
            description: description || "",
            image_url: image || "",
            role: "",
            level: 1,
            hp: 800,
            atk: 100,
            def: 80,
            spd: 70,
            exp: 0,
            exp_max: 100,
            attribute_points: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };
        } else {
          const { data: oldNFT, error: oldNFTError } = await supabase
            .from("nfts")
            .select("*")
            .eq("id", nftId)
            .maybeSingle();

          if (oldNFTError) {
            return c.json({ error: oldNFTError.message }, 500);
          }

          if (oldNFT) {
            nftPayload = {
              ...oldNFT,
              id: nftId,
              owner_account: account,
              updated_at: new Date().toISOString(),
            };

            if (name) nftPayload.name = name;
            if (description) nftPayload.description = description;
            if (image) nftPayload.image_url = image;
          }
        }

        nftResults.push(nftPayload);
      }
    }

    // ============================================================
    // STEP 3: Upsert ke database
    // ============================================================
    const { error: upsertError } = await supabase
      .from("nfts")
      .upsert(nftResults, { onConflict: "id" });

    if (upsertError) {
      console.error("Upsert error:", upsertError.message);
      return c.json({ error: upsertError.message }, 500);
    }

    // ============================================================
    // STEP 4: Fetch NFT terbaru dari DB
    // ============================================================
    const { data: dbNFTs, error: fetchError } = await supabase
      .from("nfts")
      .select("*")
      .eq("owner_account", account)
      .order("created_at", { ascending: false });

    if (fetchError) {
      console.error("Fetch error:", fetchError.message);
      return c.json({ error: fetchError.message }, 500);
    }

    // ============================================================
    // STEP 5: RETURN hasil lengkap
    // ============================================================
    return c.json({
      account,
      user: user || null,
      fungibles,
      total: TEST_MODE ? 0 : dbNFTs?.length || 0,
      nfts: TEST_MODE ? [] : dbNFTs || [],
    });
  } catch (err) {
    console.error("Error checking NFTs:", err);
    return c.json({ error: "Failed to fetch NFTs" }, 500);
  }
});
