import { Hono } from 'hono';
import alphaBattleProgressRoute from './alpha-battle-progress.js';
import alphaBattleStartRoute from './alpha-battle-start.js';
import alphaResultRoute from './alpha-result.js';
import alphaSelectMatchRoute from './alpha-select-match.js';
import alphaStatDefeatRoute from './alpha-stat-defeat.js';
import alphaStatVictoryRoute from './alpha-stat-victory.js';
import infoChallengeRoute from './info-challenge.js';
import selectNftRoute from './select-nft.js';
import selectTeamRoute from './select-team.js';
import teamBattleProgressRoute from './team-battle-progress.js';
import teamBattleStartRoute from './team-battle-start.js';
import teamResultRoute from './team-result.js';
import teamSelectMatchRoute from './team-select-match.js';
import teamStatDefeatRoute from './team-stat-defeat.js';
import teamStatVictoryRoute from './team-stat-victory.js';

export const pvpRoute = new Hono();

// Home route
pvpRoute.get('/', async (c) => {
  try {
    return c.json({ message: 'PvP Mode Home' });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Mount all sub-routes
pvpRoute.route('/alpha', alphaBattleProgressRoute);
pvpRoute.route('/alpha', alphaBattleStartRoute);
pvpRoute.route('/alpha', alphaResultRoute);
pvpRoute.route('/alpha', alphaSelectMatchRoute);
pvpRoute.route('/alpha', alphaStatDefeatRoute);
pvpRoute.route('/alpha', alphaStatVictoryRoute);
pvpRoute.route('/', infoChallengeRoute);
pvpRoute.route('/', selectNftRoute);
pvpRoute.route('/', selectTeamRoute);
pvpRoute.route('/team', teamBattleProgressRoute);
pvpRoute.route('/team', teamBattleStartRoute);
pvpRoute.route('/team', teamResultRoute);
pvpRoute.route('/team', teamSelectMatchRoute);
pvpRoute.route('/team', teamStatDefeatRoute);
pvpRoute.route('/team', teamStatVictoryRoute);