export type User = {
  id: number
  identity_address: string
  persona_label: string | null
  account_address: string | null
  account_label: string | null
  created_at: string
}

export type Account = {
  id: number
  user_id: number
  address: string
  label: string | null
  appearance_id: number | null
  created_at: string
}

export type RadixWalletResponse = {
  status: string
  data: {
    identityAddress: string
    accounts: {
      address: string
      label: string
      appearanceId: number
    }[]
    persona: {
      identityAddress: string
      label: string
    }
  }
  meta: {
    networkId: number
    dAppDefinitionAddress: string
  }
}
