import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/team/battle/:battleId/progress
 * Get real-time team battle progress via socket.io BATTLE_PROGRESS event
 * This endpoint returns latest logs
 */
route.get('/team/battle/:battleId/progress', async (c) => {
  try {
    const battleId = c.req.param('battleId');

    if (!battleId) {
      return c.json({ error: 'Missing battleId parameter' }, 400);
    }

    // Ambil latest battle logs
    const { data: logs, error } = await supabase
      .from('pvp_battle_logs')
      .select('*')
      .eq('battle_id', battleId)
      .order('timestamp', { ascending: true });

    if (error) throw error;

    // Ambil battle data
    const { data: battle } = await supabase
      .from('pvp_battles')
      .select('*')
      .eq('battle_id', battleId)
      .single();

    return c.json({
      battleId,
      status: battle?.status || 'unknown',
      logs: logs || [],
      currentProgress: logs && logs.length > 0 ? logs[logs.length - 1] : null,
      message: 'Listen to socket.io BATTLE_PROGRESS event for real-time updates',
    });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;