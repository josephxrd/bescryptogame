// routes/pve/battleResult.route.ts
import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";

const route = new Hono();

/**
 * 📘 GET /battle/:battleId/result
 * Ambil hasil akhir dari satu battle (status, tim, dan log)
 */
route.get("/battle/:battleId/result", async (c) => {
  try {
    const battleId = c.req.param("battleId");
    if (!battleId) return c.json({ error: "Missing battleId parameter" }, 400);

    // 🔹 Ambil data battle utama
    const { data: battle, error: battleError } = await supabase
      .from("pve_battles")
      .select("*")
      .eq("battle_id", battleId)
      .single();

    if (battleError || !battle)
      return c.json({ error: "Battle not found" }, 404);

    // 🔹 Ambil log progres per detik
    const { data: logs, error: logsError } = await supabase
      .from("pve_battle_logs")
      .select("*")
      .eq("battle_id", battleId)
      .order("timestamp", { ascending: true });

    if (logsError) return c.json({ error: "Failed to load battle logs" }, 500);

    // 🔹 Tentukan reward berdasarkan status
    const resultStatus = battle.status;
    let rewardGold = 0;
    let rewardExperience = 0;
    let rewardNftExp = 0;

    if (resultStatus === "win") {
      rewardGold = 100;
      rewardExperience = 50;
      rewardNftExp = 50;
    } else if (resultStatus === "lose") {
      rewardGold = 50;
      rewardExperience = 0;
      rewardNftExp = 0;
    } else {
      // draw
      rewardGold = 25;
      rewardExperience = 0;
      rewardNftExp = 25;
    }

    // 🔹 Response hasil lengkap
    return c.json({
      battleId: battle.battle_id,
      userId: battle.user_id,
      levelId: battle.level_id,
      status: resultStatus,
      playerTeam: battle.player_team,
      enemyTeam: battle.enemy_team,
      createdAt: battle.created_at,
      logs: logs || [],
      rewards: {
        gold: rewardGold,
        experience: rewardExperience,
        nftExp: rewardNftExp,
      },
    });
  } catch (error: any) {
    console.error("Error fetching battle result:", error.message);
    return c.json({ error: "Internal server error" }, 500);
  }
});

export default route;
