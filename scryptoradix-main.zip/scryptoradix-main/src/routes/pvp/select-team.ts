import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * POST /pvp/select-team
 * Validate and save team selection (must have exactly 3 NFTs)
 */
route.post('/select-team', async (c) => {
  try {
    const { userId, team, battleMode, matchMode } = await c.req.json();

    // Validate required fields
    if (!userId) {
      return c.json({ error: 'Missing userId' }, 400);
    }

    if (!team || !Array.isArray(team)) {
      return c.json({ error: 'Team must be an array' }, 400);
    }

    // Validate team has exactly 3 NFTs
    if (team.length !== 3) {
      return c.json(
        { error: `Team must have exactly 3 NFTs, got ${team.length}` },
        400
      );
    }

    // Validate each NFT has id and position
    const validPositions = ['front', 'mid', 'back'];
    for (const nft of team) {
      if (!nft.id) {
        return c.json({ error: 'Each NFT must have an id' }, 400);
      }
      if (!nft.position || !validPositions.includes(nft.position)) {
        return c.json(
          {
            error: `Invalid position. Must be one of: ${validPositions.join(
              ', '
            )}`,
          },
          400
        );
      }
    }

    // Log the selection for debugging
    console.log(`[Team Selection] User: ${userId}, Team size: ${team.length}, Battle Mode: ${battleMode}, Match Mode: ${matchMode}`);

    return c.json({
      success: true,
      message: 'Team selected successfully',
      team: team,
      userId: userId,
      battleMode: battleMode,
      matchMode: matchMode,
      instructions: 'Team has been validated. Ready for matchmaking via socket.io SELECT_TEAM_PVP event',
    });
  } catch (error) {
    console.error('[Team Selection Error]', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * GET /pvp/team/matches
 * List teams waiting for match
 */
route.get('/matches', async (c) => {
  try {
    const userId = c.req.query('userId');

    if (!userId) {
      return c.json({ error: 'Missing userId parameter' }, 400);
    }

    // Ambil daftar recent team matches
    const { data: matches, error } = await supabase
      .from('pvp_battles')
      .select(
        `id, 
         battle_id, 
         battle_mode,
         player1_id, 
         player2_id, 
         winner_id,
         created_at,
         status`
      )
      .eq('battle_mode', 'team')
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) throw error;

    return c.json({
      mode: 'team',
      totalMatches: matches?.length || 0,
      matches: matches || [],
      instructions:
        'Use socket.io SELECT_TEAM_PVP event with exactly 3 NFTs to start matchmaking',
    });
  } catch (error) {
    console.error('[Fetch Team Matches Error]', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * POST /pvp/select-team/boost
 * Boost NFT Hero (EXP / Level Up) untuk Team PVP
 * Masing-masing NFT di team dapat di-boost secara individual
 */
route.post('/select-team/boost', async (c) => {
  try {
    const body = await c.req.json<{
      nftId: string;
      account: string;
      expGain: number;
    }>();

    const { nftId, account, expGain } = body;

    if (!nftId || !account || typeof expGain !== 'number') {
      return c.json({ error: 'Missing parameters' }, 400);
    }

    // Ambil NFT
    const { data: nft, error: nftError } = await supabase
      .from('nfts')
      .select('*')
      .eq('id', nftId)
      .eq('owner_account', account)
      .single();

    if (nftError || !nft) {
      return c.json({ error: 'NFT not found or not owned by user' }, 404);
    }

    // Hitung EXP & Level NFT
    let newExp = (nft.exp || 0) + expGain;
    let newLevel = nft.level || 1;
    let newExpMax = nft.exp_max || 100;
    let newAttributePoints = nft.attribute_points || 0;
    let leveledUp = false;

    while (newExp >= newExpMax) {
      newExp -= newExpMax;
      newLevel += 1;
      newExpMax = Math.round(newExpMax * 1.25);
      newAttributePoints += 1; // Tambah 1 poin atribut setiap level up
      leveledUp = true;
    }

    const { error: updateError } = await supabase
      .from('nfts')
      .update({
        exp: newExp,
        exp_max: newExpMax,
        level: newLevel,
        attribute_points: newAttributePoints,
        updated_at: new Date().toISOString(),
      })
      .eq('id', nftId);

    if (updateError) throw updateError;

    return c.json({
      message: leveledUp
        ? 'NFT boosted successfully (+1 attribute point per level)!'
        : 'EXP added successfully.',
      nft: {
        level: newLevel,
        exp: newExp,
        exp_max: newExpMax,
        attribute_points: newAttributePoints,
      },
    });
  } catch (error: any) {
    console.error('Error boosting NFT:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * POST /pvp/select-team/boost-all
 * Boost all 3 NFTs in team at once (costs 1500 SCRYPTO total)
 */
route.post('/select-team/boost-all', async (c) => {
  try {
    const body = await c.req.json<{
      nftIds: string[];
      account: string;
      expGain: number;
    }>();

    const { nftIds, account, expGain } = body;

    if (!nftIds || !Array.isArray(nftIds) || nftIds.length !== 3) {
      return c.json({ error: 'Must provide exactly 3 NFT IDs' }, 400);
    }

    if (!account || typeof expGain !== 'number') {
      return c.json({ error: 'Missing parameters' }, 400);
    }

    // Boost semua 3 NFT
    const results = [];

    for (const nftId of nftIds) {
      // Ambil NFT
      const { data: nft, error: nftError } = await supabase
        .from('nfts')
        .select('*')
        .eq('id', nftId)
        .eq('owner_account', account)
        .single();

      if (nftError || !nft) {
        return c.json(
          { error: `NFT ${nftId} not found or not owned by user` },
          404
        );
      }

      // Hitung EXP & Level NFT
      let newExp = (nft.exp || 0) + expGain;
      let newLevel = nft.level || 1;
      let newExpMax = nft.exp_max || 100;
      let newAttributePoints = nft.attribute_points || 0;
      let leveledUp = false;

      while (newExp >= newExpMax) {
        newExp -= newExpMax;
        newLevel += 1;
        newExpMax = Math.round(newExpMax * 1.25);
        newAttributePoints += 1;
        leveledUp = true;
      }

      // Update NFT
      const { error: updateError } = await supabase
        .from('nfts')
        .update({
          exp: newExp,
          exp_max: newExpMax,
          level: newLevel,
          attribute_points: newAttributePoints,
          updated_at: new Date().toISOString(),
        })
        .eq('id', nftId);

      if (updateError) throw updateError;

      results.push({
        id: nftId,
        level: newLevel,
        exp: newExp,
        exp_max: newExpMax,
        attribute_points: newAttributePoints,
        leveledUp,
      });
    }

    console.log(`[Boost All NFTs] User: ${account}, NFTs boosted: ${nftIds.length}`);

    return c.json({
      message: 'All NFTs boosted successfully!',
      totalCost: '1500 SCRYPTO',
      nfts: results,
    });
  } catch (error: any) {
    console.error('Error boosting all NFTs:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;