import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * POST /pvp/alpha/battle/start
 * Start alpha (1v1) battle via socket.io SELECT_TEAM_PVP event
 * This is just documentation endpoint
 */
route.post('/battle/start', async (c) => {
  try {
    const { userId, nftId } = await c.req.json();

    if (!userId || !nftId) {
      return c.json({ error: 'Missing userId or nftId' }, 400);
    }

    // Validasi NFT ownership
    const { data: nft, error } = await supabase
      .from('nfts')
      .select('id, name, role, level, hp, atk, def, spd')
      .eq('id', nftId)
      .eq('owner_account', userId)
      .single();

    if (error || !nft) {
      return c.json({ error: 'NFT not found or not owned by user' }, 404);
    }

    return c.json({
      message: 'Connect to socket.io /pvp namespace to start battle',
      socketEvent: 'SELECT_TEAM_PVP',
      payload: {
        userId,
        battleMode: 'alpha',
        team: [
          {
            id: nft.id,
            position: 'front',
          },
        ],
      },
      selectedNFT: nft,
    });
  } catch (error: any) {
    console.error('Error:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;