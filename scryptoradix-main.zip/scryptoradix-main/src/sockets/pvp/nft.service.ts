// sockets/pvp/nft.service.ts
import { supabase } from "../../lib/supabase.js";

/**
 * Ambil NFT player berdasarkan userId dan daftar ID NFT yang dipilih.
 */
export async function getPlayerNFTs(userId: string, nftIds: number[]) {

  try {
    const { data, error } = await supabase
      .from("nfts")
      .select("*")
      .eq("owner_account", userId)
      .in("id", nftIds)
      .order("role", { ascending: true });

    if (error) {
      console.error("[getPlayerNFTs] Supabase error:", error);
      throw error;
    }

    if (!data || data.length === 0) {
      console.warn(
        "[getPlayerNFTs] No NFTs found. Checking without owner filter..."
      );
      // Try without owner filter to debug
      const { data: allNfts, error: err2 } = await supabase
        .from("nfts")
        .select("*")
        .in("id", nftIds);

      return [];
    }

    // Ensure all NFTs have required battle attributes with fallback values
    const nftsWithDefaults = data.map((nft: any) => ({
      ...nft,
      hp: Number(nft.hp) || 100,
      atk: Number(nft.atk) || 50,
      spd: Number(nft.spd) || 50,
      def: Number(nft.def) || 30,
    }));

    return nftsWithDefaults;
  } catch (err: any) {
    console.error("[getPlayerNFTs] Exception:", err);
    throw err;
  }
}
