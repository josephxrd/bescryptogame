import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

export const leaderboardRoute = new Hono();

/**
 * GET /leaderboard?page=1&limit=50
 * Fetch top users sorted by arena points with pagination
 */
leaderboardRoute.get('/', async (c) => {
  try {
    const page = parseInt(c.req.query('page') || '1');
    const limit = Math.min(parseInt(c.req.query('limit') || '10'), 50); // Default 10, max 50 per page
    
    if (page < 1 || limit < 1) {
      return c.json({ error: 'Invalid page or limit' }, 400);
    }

    const offset = (page - 1) * limit;

    // Count total users
    const { count: totalCount, error: countError } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true });

    if (countError) {
      console.error('Error counting users:', countError);
      return c.json({ error: 'Failed to count users' }, 500);
    }

    // Fetch paginated leaderboard data sorted by arena_points (descending)
    const { data: users, error } = await supabase
      .from('users')
      .select('account_address, persona_label, account_label, level, arena_points, pvp_wins, pvp_losses')
      .order('arena_points', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      console.error('Error fetching leaderboard:', error);
      return c.json({ error: 'Failed to fetch leaderboard' }, 500);
    }

    const leaderboard = (users || []).map((user, index) => ({
      position: offset + index + 1,
      name: user.persona_label || user.account_label || 'Unknown',
      accountAddress: user.account_address,
      level: user.level || 0,
      arenaPoints: user.arena_points || 0,
      pvpWins: user.pvp_wins || 0,
      pvpLosses: user.pvp_losses || 0,
    }));

    const totalPages = Math.ceil((totalCount || 0) / limit);

    return c.json({
      success: true,
      data: leaderboard,
      pagination: {
        currentPage: page,
        pageSize: limit,
        totalUsers: totalCount || 0,
        totalPages: totalPages,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
      },
    });
  } catch (error) {
    console.error('Error in leaderboard endpoint:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});