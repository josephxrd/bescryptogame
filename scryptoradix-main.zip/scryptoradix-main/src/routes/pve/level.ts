import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";

const route = new Hono();

route.get("/level", async (c) => {
  const { data, error } = await supabase
    .from("pve_levels")
    .select("*")
    .order("id", { ascending: true });

  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data }, 200);
});

export default route;
