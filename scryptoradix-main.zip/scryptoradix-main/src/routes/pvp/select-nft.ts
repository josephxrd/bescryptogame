import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/select-nft?userId={userId}
 * Ambil daftar NFT yang dimiliki player untuk dipilih dalam PVP
 */
route.get('/select-nft', async (c) => {
  try {
    const userId = c.req.query('userId');
    
    if (!userId) {
      return c.json({ error: 'Missing userId parameter' }, 400);
    }

    // Ambil semua NFT milik user
    const { data: nfts, error } = await supabase
      .from('nfts')
      .select('id, name, role, level, hp, atk, def, spd, image_url, description')
      .eq('owner_account', userId)
      .order('level', { ascending: false });

    if (error) throw error;

    if (!nfts || nfts.length === 0) {
      return c.json({ error: 'No NFTs found for player', nfts: [] }, 404);
    }

    return c.json({
      userId,
      nfts,
      totalNFTs: nfts.length,
    });
  } catch (error: any) {
    console.error('Error fetching NFTs:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * POST /pvp/select-nft/boost
 * Boost NFT Hero (EXP / Level Up) untuk PVP
 */
route.post('/select-nft/boost', async (c) => {
  try {
    const body = await c.req.json<{
      nftId: string;
      account: string;
      expGain: number;
    }>();

    const { nftId, account, expGain } = body;

    if (!nftId || !account || typeof expGain !== 'number') {
      return c.json({ error: 'Missing parameters' }, 400);
    }

    // Ambil NFT
    const { data: nft, error: nftError } = await supabase
      .from('nfts')
      .select('*')
      .eq('id', nftId)
      .eq('owner_account', account)
      .single();

    if (nftError || !nft) {
      return c.json({ error: 'NFT not found or not owned by user' }, 404);
    }

    // Hitung EXP & Level NFT
    let newExp = (nft.exp || 0) + expGain;
    let newLevel = nft.level || 1;
    let newExpMax = nft.exp_max || 100;
    let newAttributePoints = nft.attribute_points || 0;
    let leveledUp = false;

    while (newExp >= newExpMax) {
      newExp -= newExpMax;
      newLevel += 1;
      newExpMax = Math.round(newExpMax * 1.25);
      newAttributePoints += 1; // Tambah 1 poin atribut setiap level up
      leveledUp = true;
    }

    const { error: updateError } = await supabase
      .from('nfts')
      .update({
        exp: newExp,
        exp_max: newExpMax,
        level: newLevel,
        attribute_points: newAttributePoints,
        updated_at: new Date().toISOString(),
      })
      .eq('id', nftId);

    if (updateError) throw updateError;

    return c.json({
      message: leveledUp
        ? 'NFT boosted successfully (+1 attribute point per level)!'
        : 'EXP added successfully.',
      nft: {
        level: newLevel,
        exp: newExp,
        exp_max: newExpMax,
        attribute_points: newAttributePoints,
      },
    });
  } catch (error: any) {
    console.error('Error boosting NFT:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;