// server.ts
import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { Server as SocketIOServer } from "socket.io";
import type { Server as HttpServer } from "http";
import config from "./config/index.js";

// Import routes
import { userRoute } from "./routes/user.js";
import { homeRoute } from "./routes/main/home.js";
import { loginRoute } from "./routes/main/login.js";
import { profileRoute } from "./routes/main/profile.js";
import { collectionRoute } from "./routes/main/collection.js";
import { leaderboardRoute } from "./routes/main/leaderboard.js";
import { achievementsRoute } from "./routes/main/achievements.js";
import { walletRoute } from "./routes/auth/wallet.js";
import { pveRoute } from "./routes/pve/index.js";
import { pvpRoute } from "./routes/pvp/index.js";

// Import Socket setup
import { setupPveSocket } from "./sockets/pve/pve.socket.js";
import { setupPvpSocket } from "./sockets/pvp/pvp.socket.js";

const app = new Hono();

// Middleware
app.use("*", cors());

// Prefix semua route dengan /api
const api = app.basePath("/api");

// Mount routes
api.route("/", homeRoute);
api.route("/user", userRoute);
api.route("/auth", loginRoute);
api.route("/profile", profileRoute);
api.route("/collection", collectionRoute);
api.route("/leaderboard", leaderboardRoute);
api.route("/achievements", achievementsRoute);
api.route("/wallet", walletRoute);
api.route("/pve", pveRoute);
api.route("/pvp", pvpRoute);

// 404 handler
app.notFound((c) => c.json({ error: "Route not found" }, 404));

// Jalankan server
const server = serve(
  {
    fetch: app.fetch,
    port: config.port,
  },
  (info) => {
    console.log(`✅ Server is running on http://localhost:${info.port}`);
    console.log(`📡 Environment: ${config.nodeEnv}`);
  }
);

// --- Setup Socket.IO global ---
const io = new SocketIOServer(server as unknown as HttpServer, {
  cors: {
    origin: config.isDevelopment ? "*" : process.env.CORS_ORIGIN || "*",
  },
});

// --- Setup PVE namespace (tidak perlu return activeBattles lagi) ---
setupPveSocket(io);

// --- Setup PVP namespace ---
setupPvpSocket(io);

// --- Optional: export io untuk digunakan di route lain ---
export { io };

