// sockets/pvp/pvp.socket.ts
import { Server } from "socket.io";
import { registerBattleHandlers } from "./battle.handlers.js";
import { waitingRoomsCache } from "./cache.js";

export const setupPvpSocket = (io: Server) => {
  const pvp = io.of("/pvp");

  pvp.on("connection", (socket) => {
    registerBattleHandlers(socket, io);

    socket.on("disconnect", () => {
    });
  });

  // Start cleanup interval untuk stale rooms (setiap 3 menit)
  // Ini akan membersihkan rooms yang tidak active > 5 menit
  const cleanupInterval = setInterval(() => {
    cleanupStaleRooms(io);
  }, 3 * 60 * 1000); // 3 minutes

  // Optional: cleanup saat server shutdown
  process.on("exit", () => {
    clearInterval(cleanupInterval);
  });
};

/**
 * Helper function untuk clean up rooms yang stale (timeout lebih dari 5 menit)
 */
function cleanupStaleRooms(io: Server) {
  const now = Date.now();
  const HEARTBEAT_TIMEOUT = 5 * 60 * 1000; // 5 minutes
  const roomsToDelete: string[] = [];

  waitingRoomsCache.forEach((room, userId) => {
    if (now - room.lastHeartbeat > HEARTBEAT_TIMEOUT) {
      console.log(
        "[CLEANUP] Removing stale room for user:",
        userId,
        "inactive for:",
        Math.floor((now - room.lastHeartbeat) / 1000),
        "seconds"
      );

      // If room has matched opponent, clean opponent's reference
      if (room.matchedOpponentId) {
        const opponentRoom = waitingRoomsCache.get(room.matchedOpponentId);
        if (opponentRoom) {
          opponentRoom.matchedOpponentId = undefined;
          opponentRoom.opponentTeam = undefined;
        }
      }

      roomsToDelete.push(userId);
    }
  });

  // Delete all stale rooms
  roomsToDelete.forEach((userId) => {
    waitingRoomsCache.delete(userId);
  });
}
