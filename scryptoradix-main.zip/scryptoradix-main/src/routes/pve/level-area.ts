import { Hono } from 'hono';

const route = new Hono();

route.get('/level/:id/area/:areaId', async (c) => {
  try {
    const { id, areaId } = c.req.param();
    return c.json({ message: `Level ${id}, Area ${areaId} details` });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;