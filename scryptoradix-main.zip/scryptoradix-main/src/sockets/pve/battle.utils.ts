// modules/pve/battle.utils.ts
export function calculateTeamPower(team: any[]) {
  return team.reduce(
    (sum, n) => sum + n.hp * 0.5 + n.atk * 1.2 + n.spd * 1.1 + n.def * 0.8,
    0
  );
}
