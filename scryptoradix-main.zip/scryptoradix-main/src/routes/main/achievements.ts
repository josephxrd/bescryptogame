import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

export const achievementsRoute = new Hono();

/**
 * GET /achievements/stats/:accountAddress
 * Ambil user achievements stats (level, exp, rank, wins, losses, draws)
 */
achievementsRoute.get('/stats/:accountAddress', async (c) => {
  try {
    const accountAddress = c.req.param('accountAddress');

    const { data: user, error } = await supabase
      .from('users')
      .select('account_address, persona_label, account_label, level, exp, max_exp, coins, pvp_wins, pvp_losses, pvp_draws, arena_points, cleared_levels, created_at')
      .eq('account_address', accountAddress)
      .single();

    if (error || !user) {
      return c.json({ error: 'User not found' }, 404);
    }

    return c.json({
      success: true,
      data: {
        accountAddress: user.account_address,
        name: user.persona_label || user.account_label || 'Unknown',
        level: user.level,
        exp: user.exp,
        maxExp: user.max_exp,
        coins: user.coins,
        pvpWins: user.pvp_wins || 0,
        pvpLosses: user.pvp_losses || 0,
        pvpDraws: user.pvp_draws || 0,
        arenaPoints: user.arena_points,
        clearedLevels: user.cleared_levels || [],
        joinedAt: user.created_at,
      },
    });
  } catch (error) {
    console.error('Error fetching achievements stats:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * GET /achievements/history/:accountAddress
 * Ambil PVP battle history untuk user
 */
achievementsRoute.get('/history/:accountAddress', async (c) => {
  try {
    const accountAddress = c.req.param('accountAddress');
    const limit = c.req.query('limit') ? parseInt(c.req.query('limit')!) : 10;

    // Ambil battle history dimana user adalah player1 atau player2
    const { data: battles, error } = await supabase
      .from('pvp_battles')
      .select('id, battle_id, battle_mode, player1_id, player2_id, winner_id, loser_id, status, final_player1_progress, final_player2_progress, created_at')
      .or(`player1_id.eq.${accountAddress},player2_id.eq.${accountAddress}`)
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching battle history:', error.message);
      return c.json({ error: 'Failed to fetch battle history' }, 500);
    }

    // Transform data untuk frontend
    const history = battles?.map((battle) => {
      const isPlayer1 = battle.player1_id === accountAddress;
      const opponent = isPlayer1 ? battle.player2_id : battle.player1_id;
      const isWin = battle.winner_id === accountAddress;
      const result = isWin ? 'VICTORY' : 'DEFEAT';

      return {
        id: battle.id,
        battleId: battle.battle_id,
        mode: battle.battle_mode === 'alpha' ? 'alpha' : 'team',
        modeTitle: battle.battle_mode === 'alpha' ? 'PVP - ALPHA BATTLE' : 'PVP - TEAM BATTLE',
        opponent: opponent,
        result: result,
        timestamp: battle.created_at,
      };
    }) || [];

    return c.json({
      success: true,
      data: history,
    });
  } catch (error) {
    console.error('Error fetching history:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

/**
 * GET /achievements/top-nfts/:accountAddress
 * Ambil top 3 NFT dengan level tertinggi untuk user
 */
achievementsRoute.get('/top-nfts/:accountAddress', async (c) => {
  try {
    const accountAddress = c.req.param('accountAddress');

    const { data: topNFTs, error } = await supabase
      .from('nfts')
      .select('id, name, level, role, image_url')
      .eq('owner_account', accountAddress)
      .order('level', { ascending: false })
      .limit(3);

    if (error) {
      console.error('Error fetching top NFTs:', error.message);
      return c.json({ error: 'Failed to fetch NFTs' }, 500);
    }

    return c.json({
      success: true,
      data: topNFTs || [],
    });
  } catch (error) {
    console.error('Error fetching top NFTs:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

achievementsRoute.get('/', async (c) => {
  try {
    return c.json({ message: 'Achievements endpoint' });
  } catch (error) {
    return c.json({ error: 'Internal server error' }, 500);
  }
});