// modules/pve/battle.simulation.ts
import { Server } from "socket.io";
import { activeBattlesCache } from "./cache.js";
import { calculateTeamPower } from "./battle.utils.js";
import { applyBattleReward } from "./reward.service.js";
import { supabase } from "../../lib/supabase.js";

/**
 * 🧠 Simulasi realtime battle (berlangsung setiap detik)
 * - Battle berlangsung selama 60 detik
 * - Tim lemah akan kehabisan progress lebih cepat
 * - Tim kuat akan memiliki sisa progress di akhir
 */
export async function simulateRealtimeBattle(battle: any, io: Server) {
  const { battleId } = battle;
  activeBattlesCache.set(battleId, battle);

  // 🔹 Hitung kekuatan tim
  const playerPower = calculateTeamPower(battle.playerTeam);
  const enemyPower = calculateTeamPower(battle.enemyTeam);

  let playerProgress = 100;
  let enemyProgress = 100;
  const logs: any[] = [];

  const intervalTime = 1000; // 1 detik
  const totalDuration = 60; // 60 detik
  const baseDecay = 100 / totalDuration; // ~1.6667 per detik
  const powerRatio = playerPower / enemyPower;

  const interval = setInterval(async () => {
    const battleInCache = activeBattlesCache.get(battleId);
    if (!battleInCache) {
      clearInterval(interval);
      return;
    }

    // 🔹 Normalisasi decay berdasarkan power ratio
    if (playerPower >= enemyPower) {
      // Player lebih kuat → enemy decay lebih cepat
      playerProgress = Math.max(playerProgress - baseDecay / powerRatio, 0);
      enemyProgress = Math.max(enemyProgress - baseDecay * powerRatio, 0);
    } else {
      // Enemy lebih kuat → player decay lebih cepat
      playerProgress = Math.max(
        playerProgress - baseDecay * (1 / powerRatio),
        0
      );
      enemyProgress = Math.max(enemyProgress - baseDecay / (1 / powerRatio), 0);
    }

    logs.push({
      timestamp: Date.now(),
      playerProgress: Number(playerProgress.toFixed(2)),
      enemyProgress: Number(enemyProgress.toFixed(2)),
    });

    // 🔹 Kirim update progress ke client
    io.of("/pve").to(battleId).emit("BATTLE_PROGRESS", {
      battleId,
      playerProgress,
      enemyProgress,
    });

    // 🔹 Cek kondisi selesai
    if (playerProgress <= 0 || enemyProgress <= 0) {
      clearInterval(interval);

      const status =
        playerProgress > enemyProgress
          ? "win"
          : enemyProgress > playerProgress
          ? "lose"
          : "draw";

      battleInCache.status = status;

      // 🔹 Simpan hasil ke database
      await supabase
        .from("pve_battles")
        .update({ status })
        .eq("battle_id", battleId);
      await applyBattleReward(
        battle.userId,
        battle.levelId,
        status,
        battle.selectedNFTIds,
        battle.playerTeam
      );

      await supabase.from("pve_battle_logs").insert(
        logs.map((log) => ({
          battle_id: battleId,
          timestamp: log.timestamp,
          player_progress: log.playerProgress,
          enemy_progress: log.enemyProgress,
        }))
      );

      // 🔹 Emit event selesai ke socket
      io.of("/pve").to(battleId).emit("BATTLE_FINISHED", {
        battleId,
        status,
        playerProgress,
        enemyProgress,
      });

      activeBattlesCache.delete(battleId);
    }
  }, intervalTime);
}

/**
 * ⚡ Simulasi instan (skip battle)
 * - Menggunakan logika decay yang sama dengan versi realtime
 * - Langsung hasilkan outcome tanpa interval
 */
export async function skipBattleProgress(battle: any) {
  const { battleId } = battle;

  // 🔹 Hitung kekuatan tim
  const playerPower = calculateTeamPower(battle.playerTeam);
  const enemyPower = calculateTeamPower(battle.enemyTeam);

  let playerProgress = 100;
  let enemyProgress = 100;
  const logs: any[] = [];

  const totalDuration = 60;
  const baseDecay = 100 / totalDuration;
  const powerRatio = playerPower / enemyPower;

  for (let t = 0; t < totalDuration; t++) {
    if (playerPower >= enemyPower) {
      playerProgress = Math.max(playerProgress - baseDecay / powerRatio, 0);
      enemyProgress = Math.max(enemyProgress - baseDecay * powerRatio, 0);
    } else {
      playerProgress = Math.max(
        playerProgress - baseDecay * (1 / powerRatio),
        0
      );
      enemyProgress = Math.max(enemyProgress - baseDecay / (1 / powerRatio), 0);
    }

    logs.push({
      timestamp: Date.now(),
      playerProgress: Number(playerProgress.toFixed(2)),
      enemyProgress: Number(enemyProgress.toFixed(2)),
    });

    if (playerProgress <= 0 || enemyProgress <= 0) break;
  }

  const status =
    playerProgress > enemyProgress
      ? "win"
      : enemyProgress > playerProgress
      ? "lose"
      : "draw";

  battle.status = status;

  // 🔹 Simpan hasil ke database
  await supabase
    .from("pve_battles")
    .update({ status })
    .eq("battle_id", battleId);
  await applyBattleReward(
    battle.userId,
    battle.levelId,
    status,
    battle.selectedNFTIds,
    battle.playerTeam
  );

  await supabase.from("pve_battle_logs").insert(
    logs.map((log) => ({
      battle_id: battleId,
      timestamp: log.timestamp,
      player_progress: log.playerProgress,
      enemy_progress: log.enemyProgress,
    }))
  );

  return { status, logs, playerProgress, enemyProgress };
}
