import { Hono } from 'hono';
import { supabase } from '../../lib/supabase.js';

const route = new Hono();

/**
 * GET /pvp/team/battle/:battleId/result
 * Ambil hasil final dari team battle
 */
route.get('/battle/:battleId/result', async (c) => {
  try {
    const battleId = c.req.param('battleId');

    if (!battleId) {
      return c.json({ error: 'Missing battleId parameter' }, 400);
    }

    // Ambil data battle
    const { data: battle, error: battleError } = await supabase
      .from('pvp_battles')
      .select('*')
      .eq('battle_id', battleId)
      .single();

    if (battleError || !battle) {
      return c.json({ error: 'Battle not found' }, 404);
    }

    // Ambil semua logs
    const { data: logs, error: logsError } = await supabase
      .from('pvp_battle_logs')
      .select('*')
      .eq('battle_id', battleId)
      .order('timestamp', { ascending: true });

    if (logsError) throw logsError;

    return c.json({
      battleId: battle.battle_id,
      battleMode: battle.battle_mode,
      player1Id: battle.player1_id,
      player2Id: battle.player2_id,
      player1Team: battle.player1_team,
      player2Team: battle.player2_team,
      firstTurnPlayerId: battle.first_turn_player_id,
      winnerId: battle.winner_id,
      loserId: battle.loser_id,
      status: battle.status,
      finalPlayer1Progress: battle.final_player1_progress,
      finalPlayer2Progress: battle.final_player2_progress,
      createdAt: battle.created_at,
      logs: logs || [],
    });
  } catch (error: any) {
    console.error('Error fetching battle result:', error.message);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default route;