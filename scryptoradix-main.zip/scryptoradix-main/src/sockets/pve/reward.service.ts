import { supabase } from "../../lib/supabase.js";

export async function applyBattleReward(
  userId: string,
  levelId: number,
  status: "win" | "lose" | "draw",
  selectedNFTIds: string[],
  playerTeam: { id: string; position: string; role: string }[] // ← DARI START_BATTLE
) {
  try {
    // === AMBIL LEVEL ===
    const { data: levelData, error: levelError } = await supabase
      .from("pve_levels")
      .select("reward_gold, reward_xp")
      .eq("id", levelId)
      .single();

    if (levelError || !levelData) return;

    // === AMBIL USER ===
    const { data: userData } = await supabase
      .from("users")
      .select(
        "coins, exp, total_exp, max_exp, level, pve_progress, cleared_levels"
      )
      .eq("account_address", userId)
      .single();

    if (!userData) return;

    let {
      coins,
      exp,
      total_exp,
      max_exp,
      level,
      pve_progress,
      cleared_levels,
    } = userData;

    let cleared = Array.isArray(cleared_levels) ? cleared_levels : [];

    // === REWARD ===
    let rewardGold = 0;
    let profileXp = 0;
    let nftXpGain = 0;

    if (status === "win") {
      rewardGold = 100;
      profileXp = 50;

      const firstClear = !cleared.includes(levelId);
      nftXpGain = 50;

      if (firstClear) cleared.push(levelId);
    } else if (status === "lose") {
      rewardGold = 50;
      profileXp = 0;
      nftXpGain = 0;
    } else {
      rewardGold = 25;
      profileXp = 0;
      nftXpGain = 25;
    }

    // =============================================
    // UPDATE NFT XP
    // =============================================
    const { data: nfts } = await supabase
      .from("nfts")
      .select("id, exp, exp_max, level, attribute_points, role")
      .in("id", selectedNFTIds);

    if (nfts && nfts.length > 0) {
      for (const nft of nfts) {
        let newExp = nft.exp + nftXpGain;
        let newLevel = nft.level;
        let newExpMax = nft.exp_max || 100;
        let attributePoints = nft.attribute_points || 0;

        if (newExp >= newExpMax) {
          newExp -= newExpMax;
          newLevel++;
          newExpMax = Math.round(newExpMax * 1.25);
          attributePoints += 5;
        }

        await supabase
          .from("nfts")
          .update({
            exp: newExp,
            exp_max: newExpMax,
            level: newLevel,
            attribute_points: attributePoints,
            updated_at: new Date().toISOString(),
          })
          .eq("id", nft.id);
      }
    }

    // =============================================
    // 🚀 SET ROLE NFT → ROLE DIAMBIL DARI POSITION
    // =============================================

    const positionToRole: Record<string, string> = {
      front: "Frontline",
      mid: "Attacker",
      back: "Backline",
    };

    if (!nfts || nfts.length === 0) return;

    for (const nft of nfts) {
      // Jika NFT SUDAH MEMILIKI ROLE → SKIP
      if (nft.role && nft.role.trim() !== "") continue;

      const meta = playerTeam.find((p) => p.id === nft.id);
      if (!meta) continue;

      const mappedRole =
        positionToRole[meta.position as keyof typeof positionToRole] || "";

      await supabase
        .from("nfts")
        .update({
          role: mappedRole,
          updated_at: new Date().toISOString(),
        })
        .eq("id", nft.id);
    }

    // =============================================
    // UPDATE USER
    // =============================================

    coins += rewardGold;
    exp += profileXp;
    total_exp += profileXp;

    if (exp >= max_exp) {
      exp -= max_exp;
      level++;
      max_exp = Math.round(max_exp * 1.2);
    }

    if (status === "win") {
      pve_progress = Math.max(pve_progress, levelId + 1);
    }

    await supabase
      .from("users")
      .update({
        coins,
        exp,
        total_exp,
        max_exp,
        level,
        pve_progress,
        cleared_levels: cleared,
        updated_at: new Date().toISOString(),
      })
      .eq("account_address", userId);
  } catch (err) {
    console.error("Reward update failed:", err);
  }
}
