import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";

export const collectionRoute = new Hono();

// --- GET: Ambil semua NFT milik user ---
collectionRoute.get("/", async (c) => {
  try {
    const account = c.req.query("account");

    if (!account) {
      return c.json({ error: "Missing account address" }, 400);
    }

    const { data: nfts, error } = await supabase
      .from("nfts")
      .select("*")
      .eq("owner_account", account);

    if (error) throw error;

    return c.json({ nfts });
  } catch (error) {
    console.error("Error fetching NFTs:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// --- POST: Alokasikan poin atribut ---
collectionRoute.post("/allocate", async (c) => {
  try {
    const body = await c.req.json<{
      nftId: string;
      account: string;
      allocation: {
        hp?: number;
        atk?: number;
        def?: number;
        spd?: number;
      };
    }>();

    const { nftId, account, allocation } = body;

    if (!nftId || !account || !allocation) {
      return c.json({ error: "Missing parameters" }, 400);
    }

    const { data: nft, error: nftError } = await supabase
      .from("nfts")
      .select("*")
      .eq("id", nftId)
      .eq("owner_account", account)
      .single();

    if (nftError || !nft) {
      return c.json({ error: "NFT not found or not owned by user" }, 404);
    }

    const totalAllocated =
      (allocation.hp ?? 0) +
      (allocation.atk ?? 0) +
      (allocation.def ?? 0) +
      (allocation.spd ?? 0);

    if (totalAllocated <= 0) {
      return c.json({ error: "No points allocated" }, 400);
    }

    if ((nft.attribute_points ?? 0) < totalAllocated) {
      return c.json({ error: "Not enough attribute points" }, 400);
    }

    const newHp = nft.hp + (allocation.hp ?? 0) * 10;
    const newAtk = nft.atk + (allocation.atk ?? 0) * 2;
    const newDef = nft.def + (allocation.def ?? 0) * 1;
    const newSpd = nft.spd + (allocation.spd ?? 0) * 3;

    const { error: updateError } = await supabase
      .from("nfts")
      .update({
        hp: newHp,
        atk: newAtk,
        def: newDef,
        spd: newSpd,
        attribute_points: nft.attribute_points - totalAllocated,
        updated_at: new Date().toISOString(),
      })
      .eq("id", nftId);

    if (updateError) throw updateError;

    return c.json({
      message: "Attributes allocated successfully",
      updated: {
        hp: newHp,
        atk: newAtk,
        def: newDef,
        spd: newSpd,
        remaining_points: nft.attribute_points - totalAllocated,
      },
    });
  } catch (error) {
    console.error("Error allocating points:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// --- POST: Upgrade NFT Hero (EXP / Level Up) ---
collectionRoute.post("/upgrade", async (c) => {
  try {
    const body = await c.req.json<{
      nftId: string;
      account: string;
      expGain: number;
      multiplier?: number;
    }>();

    const { nftId, account, expGain, multiplier = 1 } = body;

    if (!nftId || !account || typeof expGain !== "number") {
      return c.json({ error: "Missing parameters" }, 400);
    }

    // Validasi multiplier (max 50)
    const validMultiplier = Math.min(Math.max(multiplier, 1), 50);

    // Ambil NFT
    const { data: nft, error: nftError } = await supabase
      .from("nfts")
      .select("*")
      .eq("id", nftId)
      .eq("owner_account", account)
      .single();

    if (nftError || !nft) {
      return c.json({ error: "NFT not found or not owned by user" }, 404);
    }

    // Hitung EXP & Level NFT dengan multiple upgrade
    let newExp = (nft.exp || 0);
    let newLevel = nft.level || 1;
    let newExpMax = nft.exp_max || 100;
    let newAttributePoints = nft.attribute_points || 0;
    let leveledUp = 0;

    // Loop sesuai multiplier
    for (let i = 0; i < validMultiplier; i++) {
      newExp += expGain;

      // Check apakah level up
      while (newExp >= newExpMax) {
        newExp -= newExpMax;
        newLevel += 1;
        newExpMax = Math.round(newExpMax * 1.25);
        newAttributePoints += 5; // Tambah 5 poin atribut setiap level up
        leveledUp += 1;
      }
    }

    const { error: updateError } = await supabase
      .from("nfts")
      .update({
        exp: newExp,
        exp_max: newExpMax,
        level: newLevel,
        attribute_points: newAttributePoints,
        updated_at: new Date().toISOString(),
      })
      .eq("id", nftId);

    if (updateError) throw updateError;

    return c.json({
      message:
        leveledUp > 0
          ? `NFT upgraded ${validMultiplier} times! Leveled up ${leveledUp} times (+${leveledUp} attribute points)!`
          : `NFT upgraded ${validMultiplier} times. EXP added successfully.`,
      nft: {
        level: newLevel,
        exp: newExp,
        exp_max: newExpMax,
        attribute_points: newAttributePoints,
      },
    });
  } catch (error) {
    console.error("Error upgrading NFT:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});
