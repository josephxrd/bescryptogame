import { Hono } from "hono";
import { supabase } from "../../lib/supabase.js";

const route = new Hono();

const generateBattleId = (userId: string) => `${userId}_${Date.now()}`;

route.post("/battle/start", async (c) => {
  try {
    const { userId, levelId } = await c.req.json();

    if (!userId || !levelId)
      return c.json({ error: "Missing userId or levelId" }, 400);

    const battleId = generateBattleId(userId);

    // 🔹 Ambil NFT player
    const { data: playerTeam, error: playerError } = await supabase
      .from("player_nfts")
      .select("*")
      .eq("owner_account", userId);

    if (playerError) throw playerError;
    if (!playerTeam || playerTeam.length === 0)
      return c.json({ error: "No NFTs found for player" }, 404);

    // 🔹 Ambil NFT musuh (bot)
    const { data: enemyTeam, error: enemyError } = await supabase
      .from("pve_level_nfts")
      .select(
        `id, name, role, level, hp, atk, def, spd, image_url, description`
      )
      .eq("level_id", levelId)
      .order("role", { ascending: true });

    if (enemyError) throw enemyError;
    if (!enemyTeam || enemyTeam.length === 0)
      return c.json({ error: "No NFT enemies found for this level" }, 404);

    // 🔹 Simpan ke Supabase pve_battles
    const { error: insertError } = await supabase.from("pve_battles").insert([
      {
        battle_id: battleId,
        user_id: userId,
        level_id: levelId,
        player_team: playerTeam,
        enemy_team: enemyTeam,
      },
    ]);

    if (insertError) throw insertError;

    return c.json({ message: "Battle started", battleId });
  } catch (err: any) {
    console.error(err);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// 🔹 Endpoint ambil NFT bot (tetap sama)
route.get("/battle/bot-nfts", async (c) => {
  try {
    const levelId = c.req.query("level_id");

    if (!levelId) {
      return c.json({ error: "Missing level_id parameter" }, 400);
    }

    const { data: nfts, error } = await supabase
      .from("pve_level_nfts")
      .select(
        `
        id,
        name,
        role,
        level,
        hp,
        atk,
        def,
        spd,
        image_url,
        description,
        pve_levels (
          id,
          name,
          difficulty,
          reward_gold,
          reward_xp
        )
        `
      )
      .eq("level_id", levelId)
      .order("role", { ascending: true });

    if (error) throw error;
    if (!nfts || nfts.length === 0)
      return c.json({ message: "No NFT enemies found for this level" }, 404);

    return c.json({ level_id: levelId, enemies: nfts });
  } catch (err: any) {
    console.error("Error fetching bot NFTs:", err.message);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// 🔹 Endpoint ambil data battle dari Supabase
route.get("/battle/:battleId", async (c) => {
  const battleId = c.req.param("battleId");
  const { data, error } = await supabase
    .from("pve_battles")
    .select("*")
    .eq("battle_id", battleId)
    .single();

  if (error || !data) return c.json({ error: "Battle not found" }, 404);

  return c.json({ battle: data });
});


export default route;
