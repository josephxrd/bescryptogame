// sockets/pvp/battle.simulation.ts
import { Server } from "socket.io";
import { activeBattlesCache } from "./cache.js";
import { calculateTeamPower } from "./battle.utils.js";
import { applyPVPBattleReward, applyPVPBattleDrawReward } from "./reward.service.js";
import { supabase } from "../../lib/supabase.js";

interface BattleLog {
  timestamp: number;
  player1Progress: number;
  player2Progress: number;
}

/**
 * Simulasi realtime battle PVP (berlangsung setiap detik)
 * - Battle berlangsung sampai salah satu tim habis (progress <= 0)
 * - Tim lemah akan kehabisan progress lebih cepat berdasarkan power ratio
 * - Tanpa turn-based, pure kalkulasi per detik
 */
export async function simulateRealtimePVPBattle(battle: any, io: Server) {
  const { battleId, player1Id, player2Id } = battle;
  activeBattlesCache.set(battleId, battle);

  // 🔹 Hitung kekuatan tim
  const player1Power = calculateTeamPower(battle.player1Team);
  const player2Power = calculateTeamPower(battle.player2Team);

  let player1Progress = 100;
  let player2Progress = 100;
  const logs: BattleLog[] = [];

  const intervalTime = 1000; // 1 detik
  const battleDuration = 10; // 10 detik (alpha dan team)
  let elapsedSeconds = 0;

  // Base decay per detik: 100 progress / 10 detik = 10 per detik (jika seimbang)
  const baseDecay = 100 / battleDuration;
  const powerRatio = player1Power / player2Power;

  const interval = setInterval(async () => {
    const battleInCache = activeBattlesCache.get(battleId);
    if (!battleInCache) {
      clearInterval(interval);
      return;
    }

    elapsedSeconds++;

    // 🔹 Hitung decay per detik berdasarkan power ratio
    // Semakin besar selisih power, semakin cepat tim lemah decay
    let p1Decay: number;
    let p2Decay: number;

    if (player1Power >= player2Power) {
      // Player1 lebih kuat → player2 decay lebih cepat
      p1Decay = baseDecay / Math.max(powerRatio, 0.1); // Tim kuat: decay lambat
      p2Decay = baseDecay * Math.max(powerRatio, 0.1); // Tim lemah: decay cepat
    } else {
      // Player2 lebih kuat → player1 decay lebih cepat
      p1Decay = baseDecay * Math.max(1 / powerRatio, 0.1); // Tim lemah: decay cepat
      p2Decay = baseDecay / Math.max(1 / powerRatio, 0.1); // Tim kuat: decay lambat
    }

    // Apply decay
    player1Progress = Math.max(player1Progress - p1Decay, 0);
    player2Progress = Math.max(player2Progress - p2Decay, 0);

    logs.push({
      timestamp: Date.now(),
      player1Progress: Number(player1Progress.toFixed(2)),
      player2Progress: Number(player2Progress.toFixed(2)),
    });

    // 🔹 Kirim update progress ke client setiap detik
    io.of("/pvp").to(battleId).emit("BATTLE_PROGRESS", {
      battleId,
      player1Progress,
      player2Progress,
    });

    // 🔹 Cek kondisi selesai: salah satu progress <= 0 ATAU 60 detik habis
    if (
      player1Progress <= 0 ||
      player2Progress <= 0 ||
      elapsedSeconds >= battleDuration
    ) {
      clearInterval(interval);

      // Tentukan pemenang
      let status: "win" | "lose" | "draw";
      let winnerId: string | undefined;
      let loserId: string | undefined;

      if (player1Progress > player2Progress) {
        status = "win";
        winnerId = player1Id;
        loserId = player2Id;
      } else if (player2Progress > player1Progress) {
        status = "lose";
        winnerId = player2Id;
        loserId = player1Id;
      } else {
        status = "draw";
      }

      battleInCache.status = "finished";
      battleInCache.winner = winnerId;

      // 🔹 Simpan hasil ke database (UPDATE bukan INSERT karena record sudah ada)
      await supabase.from("pvp_battles")
        .update({
          winner_id: winnerId,
          loser_id: loserId,
          status: status === "draw" ? "draw" : "completed",
          final_player1_progress: player1Progress,
          final_player2_progress: player2Progress,
        })
        .eq("battle_id", battleId);

      // 🔹 Terapkan reward untuk kedua player
      if (winnerId && loserId && status !== "draw") {
        await applyPVPBattleReward(
          winnerId,
          loserId,
          battle.battleMode,
          status === "win" ? battle.player1Team : battle.player2Team,
          status === "win" ? battle.player2Team : battle.player1Team
        );
      } else if (status === "draw") {
        await applyPVPBattleDrawReward(
          player1Id,
          player2Id,
          battle.battleMode,
          battle.player1Team,
          battle.player2Team
        );
      }

      // 🔹 Simpan battle logs
      await supabase.from("pvp_battle_logs").insert(
        logs.map((log) => ({
          battle_id: battleId,
          timestamp: log.timestamp,
          player1_progress: log.player1Progress,
          player2_progress: log.player2Progress,
        }))
      );

      // 🔹 Emit event selesai ke socket
      io.of("/pvp").to(battleId).emit("BATTLE_FINISHED", {
        battleId,
        status,
        player1Progress,
        player2Progress,
        winner: winnerId,
        loser: loserId,
        durationSeconds: elapsedSeconds,
      });

      activeBattlesCache.delete(battleId);

      // 🔹 Hapus waiting room untuk kedua player setelah battle selesai
      // Import langsung dari cache module untuk menghindari race condition
      const { waitingRoomsCache: cache } = await import("./cache.js");
      cache.delete(battle.player1Id);
      cache.delete(battle.player2Id);

      console.log(
        "[simulateRealtimePVPBattle] Cleaned up battle and waiting rooms",
        { battleId, player1Id: battle.player1Id, player2Id: battle.player2Id }
      );
    }
  }, intervalTime);
}
